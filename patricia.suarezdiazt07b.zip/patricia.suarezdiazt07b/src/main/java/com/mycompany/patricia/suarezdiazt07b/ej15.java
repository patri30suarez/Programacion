
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

    /*Realiza un programa que tenga un ArrayList llamado AlturaAlumnos que mantenga una lista con las
alturas de los alumnos de un centro. Serán valores positivos entre 0,50 y 2,50 redondeados a dos decimales. El
programa tendrá las siguientes funciones (accesibles mediante un menú):
a. Añadir altura.
b. Mostrar lista actual con el número de posición
c. Eliminar por posición. Se le pasa como parámetro una posición y elimina la altura en dicha posición.
d. Eliminar por valor. Se le pasa como parámetro una altura y elimina todas las posiciones en las que se
encuentre dicha altura. Devuelve la cantidad de eliminaciones.
e. Ordenar la lista.
f. Vaciar la lista */

public class ej15 {
    
    public static void main(String[] args) {
    Scanner t = new Scanner(System.in);
    char opcion ='0';
    ArrayList <Double> AlturaAlumnos = new ArrayList <> ();
    
    
    do{
        System.out.println("a. Añadir altura");
        System.out.println("b. Mostrar lista actual con el número de posición");
        System.out.println("c. Eliminar por posición. Se le pasa una posición");
        System.out.println("d. Eliminar por valor. Se le pasa una altura");
        System.out.println("e. Ordenar la lista");
        System.out.println("f. Vaciar la lista");
        System.out.println("g. Salir");
        
        opcion = t.nextLine().charAt(0);
        
        switch(opcion){
            
            case 'a':
                boolean bucle = true;
                double altura = 0;
                do{
                System.out.println("Introduce la altura, debe ser entre 0.5 y 2.5");
                altura = t.nextDouble();
                altura = Math.round(altura *100) /100d;
                if(altura >= 0.5d && altura <= 2.5d){
                    AlturaAlumnos.add(altura);
                    bucle = false;
                }else{
                    bucle = true;
                    System.out.println("Altura incorrecta");
                }
                t.nextLine();
                }while (bucle);
                break;
            case 'b':
                if(AlturaAlumnos.size()==0)System.out.println("Array vacio");
                else{
                for (int i = 0; i < AlturaAlumnos.size(); i++) {
                    System.out.println((i+1)+" Altura "+AlturaAlumnos.get(i));
                }}
                break;
            case 'c':
                boolean bucle1 = true;
                do{
                System.out.println("Introduce la posicion quieres eliminar");
                int posicion = 0;
                posicion = t.nextInt();
                if(posicion<AlturaAlumnos.size()){
                    AlturaAlumnos.remove(posicion);
                    bucle1 = false;
                }else if (AlturaAlumnos.size()==0){
                    System.out.println("Array vacio");
                    bucle1=false;
                }
                else{
                    System.out.println("Posicion incorrecta");
                    bucle1= true;
                }
                }while(bucle1);
                t.nextLine();
                break;
            case 'd':
                double altura1 = 0;
                System.out.println("Introduce la altura que quieres eliminar");
                altura1 = t.nextDouble();
                Double deAltura = new Double(altura1);
                if(AlturaAlumnos.remove(deAltura)==false){
                    System.out.println("Altura incorrecta");
                }
                do{
                    AlturaAlumnos.remove(deAltura);
                }while(AlturaAlumnos.remove(deAltura));
                t.nextLine();
                break;
            case 'e':
                Collections.sort(AlturaAlumnos);
                System.out.println("Array ordenado");
                for (int i = 0; i < AlturaAlumnos.size(); i++) {
                    System.out.println((i+1)+" Altura "+AlturaAlumnos.get(i));
                }
                break;
            case 'f':
                AlturaAlumnos.clear();
                System.out.println("Array borrado");
                break;
            case 'g':System.out.println("Salir");
                break;
            default: System.out.println("Opción incorrecta");
            
        }
    }while(opcion!='g');
    }
    
}
