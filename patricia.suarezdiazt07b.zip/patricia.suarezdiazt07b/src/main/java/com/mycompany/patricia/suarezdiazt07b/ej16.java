package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Scanner;

/*Realizar un programa al que se le vayan introduciendo por teclado números enteros. El programa
dispone de dos ArrayList, uno llamado positivos y otro negativos. Se trata de meter los números
introducidos en uno u otro según su signo hasta que finalice el programa (esto ocurrirá cuando se introduzca cero).
Al finalizar, mostrará la media aritmética de cada ArrayList.
 */
public class ej16 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        int numero = 0;
        int contPositivo = 0;
        int contNegativo = 0;
        double medPositivo = 0;
        double medNegativo = 0;
        ArrayList<Integer> positivos = new ArrayList<>();
        ArrayList<Integer> negativos = new ArrayList<>();
        do {
            System.out.println("Introduce un numero");
            numero = t.nextInt();
            if (numero > 0) {
                positivos.add(numero);
            } else if (numero < 0) {
                negativos.add(numero);
            } else {
                System.out.println("Fin");
            }
        } while (numero != 0);
        for (int i = 0; i < positivos.size(); i++) {
            contPositivo += positivos.get(i);
        }
        for (int i = 0; i < negativos.size(); i++) {
            contNegativo += negativos.get(i);
        }
        if (positivos.size() > 0) {
            medPositivo = contPositivo / (double) positivos.size();
        }
        if (negativos.size() > 0) {
            medNegativo = contPositivo / (double) negativos.size();
        }

        System.out.println("La media de los positivos es " + medPositivo);
        System.out.println("La media de los negativos es " + medNegativo);
    }
}
