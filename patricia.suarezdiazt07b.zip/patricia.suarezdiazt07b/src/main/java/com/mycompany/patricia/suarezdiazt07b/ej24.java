/*
 Realizar un programa con una función a la que se le pasan dos ArrayList de enteros como parámetros y
nos devuelva true si los dos ArrayList tienen los mismos elementos, aunque sean en otro orden, y devuelva false en
caso contrario (suponemos que no tienen valores repetidos).
 */
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ej24 {

    public static void main(String[] args) {
   Scanner t = new Scanner(System.in);
        Integer num=1;
        ArrayList<Integer> primero = new ArrayList<>();
        ArrayList<Integer> segundo = new ArrayList<>();
        System.out.println("Primer ArrayList, introducide 0 para el siguiente");
        do{
            System.out.println("Introduce un numero");
            num = t.nextInt();
            if(num==0){
                System.out.println("Segundo ArrayList");
            }
            else{
                primero.add(num);
            }
        }while(num!=0);
        System.out.println("Segundo ArrayList, introducide 0 para comprobar");
        do{
            System.out.println("Introduce un numero");
            num = t.nextInt();
            if(num==0){
                System.out.println("Comprobacion");
            }
            else{
                segundo.add(num);
            }
        }while(num!=0);
        Collections.sort(primero);
        Collections.sort(segundo);
        if(primero.equals(segundo)){
            System.out.println("Los ArrayList son iguales");
        }
        else{
            System.out.println("Los ArrayList son diferentes");
        }
    }
    
}
