/*
Realizar un programa que tenga una función a la que se le pasa un entero y devuelva un ArrayList con
todos sus divisores
 */
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Scanner;

public class ej18 {

    public static void main(String[] args) {
      Scanner t = new Scanner(System.in);
int num = 0;
ArrayList<Integer> div = new ArrayList<>();
        System.out.println("Introduce un numero");
        num = t.nextInt();
        div = divisores(num);
        System.out.println("Los divisores son");
        for (int i = 0; i < div.size(); i++) {
            System.out.println(div.get(i));
            
        }
        
    }
    
    
    
    
    public static ArrayList<Integer> divisores(int num){
        ArrayList<Integer> div = new ArrayList<>();
        div.add(num);
        int i = num / 2;
        while (i>0){
            if (num % i == 0){
                div.add(i);
            }
            i--;
        }
        return div;
    } 
}
