/*
Realiza una clase llamada Primitiva2 similar a la clase Primitiva, pero empleando ahora una ArrayList,
y aprovechando los métodos de los que dispone para simplificar la generación de números sin repetidos. Además,
los números premiados se mantendrán ordenados y, por último, la búsqueda de los números jugados en el ArrayList
de los premiados se requiere que se haga de forma dicotómica. Rehacer los 3 programas del ejercicio anterior de la
Primitiva pero usando esta nueva clase.
 Programa que el usuario introduzca los 6 números de su boleto y le diga cuantos acertó.
 Programa en el que se generen 1000 boletos al azar y nos informe de cuantos boletos hay con 3, 4, 5
y 6 aciertos (a lo mejor es necesario crear un nuevo método en la clase Primitiva para generar
boletos al azar).
 Programa con un bucle que genere boletos hasta que acierte los 6 números ¿Cuántos boletos has
tenido que crear?
Prueba a hacer una nueva versión de la clase, sería Primitiva3, que sea igual que
Primitiva2, pero con Array en vez de ArrayList. Como no dispones de métodos para
ordenar ni para búsqueda dicotómica deberás construirlos tú mismo.
 */
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ej17 {

    public static void main(String[] args) {
           Scanner t = new Scanner(System.in);
        ArrayList<Integer> boPremio= new ArrayList<>();
        ArrayList<Integer> bo = new ArrayList<>();
        ArrayList<Integer> bo1 = new ArrayList<>();
        ArrayList<Integer> boAc= new ArrayList<>(); 
        Integer num = 0;
        int ac = 0;
        int tres = 0;
        int cuatro = 0;
        int cinco = 0;
        int seis = 0;
        int cont = 0;
        boolean bucle = true;

        Primitiva2 primitiva = new Primitiva2(boPremio);

        for (int i = 0; i < boPremio.size(); i++) {
            System.out.println(boPremio.get(i));
        }

        System.out.println("Introduce los numeros del boleto");
        for (int i = 0; i < 6; i++) {
            num = (Integer) t.nextInt();
            bo.add(num);
        }
        Collections.sort(bo);
        ac = primitiva.aciertos(bo);
        System.out.println("Has acertado " + ac + "numeros");
        
        for (int i = 0; i < 1000; i++) {
            bo1 = primitiva.generar();
            ac = 0;
            ac = primitiva.aciertos(bo1);
            if(ac == 3) tres++;
            if(ac == 4) cuatro++;
            if(ac == 5) cinco++;
            if(ac == 6) seis++;
        }
        System.out.println("Ha acertado");
        System.out.println(tres+" boletos han tenido tres aciertos");
        System.out.println(cuatro+" boletos han tenido cuatro aciertos");
        System.out.println(cinco+" boletos han tenido cinco aciertos");
        System.out.println(seis+" boletos han tenido seis aciertos");
        
        
        while(bucle){
            
            boAc = primitiva.generar();
            ac = primitiva.aciertos(boAc);
            cont++;
            if (ac == 6) bucle = false;
        }
        System.out.println("Se han creado "+cont+" boletos para acertar");
    }
    
}
