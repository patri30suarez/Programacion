package com.mycompany.patricia.suarezdiazt07b;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class Primitiva2 {
     public ArrayList<Integer> premiado;
    Primitiva2(ArrayList<Integer> boleto){ 
        Random r = new Random();
        Integer num = 0;
        int i=0;
        do{
            num = r.nextInt(49)+1;
            if(boleto.indexOf(num)==-1){
                boleto.add(num);
                i++;
            }
        }while(i<6);
        Collections.sort(boleto);
        premiado = boleto;
    }
    
    public int aciertos (ArrayList<Integer> boleto){
        int ac = 0;
        for (int i = 0; i < premiado.size(); i++) {
            if (Collections.binarySearch(premiado, boleto.get(i)) >= 0) {
                ac++;
            }
        }
        return ac;
    }
    public ArrayList<Integer> generar(){
        ArrayList<Integer> boleto = new ArrayList<>();
        Random r = new Random();
        Integer num = 0;
        int i=0;
        do{
            num = r.nextInt(49)+1;
            if(boleto.indexOf(num)==-1){
                boleto.add(num);
                i++;
            }
        }while(i<6);
        Collections.sort(boleto);
        return boleto;
    }

}

