/*
 Realizar una programa con un ArrayList bidimensional llamado edadesAlumnos en el que cada fila
representa cada aula y cada columna los alumnos dentro del aula. El programa solicitará por teclado las edades de
los alumnos (si se introduce 0 quiere decir que se acabó con esa clase y se pasa a la siguiente y si se introduce -1
finaliza el programa). Una vez introducidos todos los valores, mostrar todas las edades introducidas (cada aula en
una fila).
 */
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Scanner;

public class ej25 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
ArrayList<ArrayList<Integer>> edades = new ArrayList <>();
Integer num = 1;
ArrayList<Integer> clase = new ArrayList<>();
edades.add(clase);
int codigo = 0;

        System.out.println("Colegio");
        System.out.println("Introduce un 0 para cambiar¡ de clase y -1 para salir");

        do{
    System.out.println("Introduce la edad ");
    num = t.nextInt();
    if(num == 0){
        System.out.println("Otra clase");
        clase = new ArrayList<>();
        edades.add(clase);
        codigo++;
    }
    else if(num != -1){
    edades.get(codigo).add(num);        
    }
    else{
        System.out.println("Salir");
    }
}while(num!=-1);
        
        for (int i = 0; i < edades.size(); i++) {
            System.out.print("Clase "+(i+1)+" edades ");
            for (int j = 0; j < edades.get(i).size(); j++) {
                System.out.print(edades.get(i).get(j)+" ");
            }
            
        }
    }
    
}
