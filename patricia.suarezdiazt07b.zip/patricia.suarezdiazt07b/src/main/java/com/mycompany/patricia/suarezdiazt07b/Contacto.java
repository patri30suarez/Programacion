package com.mycompany.patricia.suarezdiazt07b;
import java.time.LocalDate;
import java.time.Month;


public class Contacto {
 public String nombre;
 public long numero;
 public LocalDate fechaAltaAgenda;
 Contacto (String no, long nu,LocalDate fe){
 this.nombre = no;
 this.numero = nu;
 this.fechaAltaAgenda = fe;
 }
  Contacto (String no, long nu){
 this.nombre = no;
 this.numero = nu;
 this.fechaAltaAgenda = LocalDate.of(0, Month.JANUARY, 0);
 }
    Contacto (String no, long nu, String fecha){
 this.nombre = no;
 this.numero = nu;
 this.fechaAltaAgenda = LocalDate.parse(fecha);
 }
}
