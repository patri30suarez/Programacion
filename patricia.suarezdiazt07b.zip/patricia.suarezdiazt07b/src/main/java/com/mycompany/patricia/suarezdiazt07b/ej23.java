/*
Realizar el programa que simule el comportamiento de una “cola” FIFO con los nombres de pacientes
que esperan en la consulta del médico. Tendrá un menú con las siguientes opciones 
a) Llega un paciente (esto es,Introducir elemento al final de la cola)
b) Llamar al paciente para ser atendido (esto es, sacar el primer elemento de la cola) mostrándolo por pantalla 
c) Mostrar el estado de la cola 
d) salir de programa. 
 */
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Scanner;

public class ej23 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
char menu = '0';
ArrayList <String> pacientes = new ArrayList<>();
String nombre = new String();

    do{
        System.out.println("a)Llega paciente");
        System.out.println("b)Llamar a paciente");
        System.out.println("c)Mostrar el estado de la cola");
        System.out.println("d)Salir del programa");
    menu = t.nextLine().charAt(0);
    
    switch(menu){
        case 'a':
            System.out.println("Introduce el nombre");
            nombre = t.nextLine();
            pacientes.add(nombre);
            System.out.println("Paciente en espera");
            break;
        case 'b':
            if(pacientes.size()!=0){
                  System.out.println("El paciente "+pacientes.get(0)+" pase a ser atendido");
                pacientes.remove(0);
                
            }
            else{
               System.out.println("No hay pacientes");
            }
            break;
        case 'c':
            if(pacientes.size()!=0){
                 System.out.println("Esta es la lista de pacientes que estan esperando");
                for (int i = 0; i < pacientes.size(); i++) {
                    System.out.println("Paciente numero "+(i+1)+" "+pacientes.get(i));
                }
                
            }
            else{
               System.out.println("No hay pacientes esperando");
            }
            break;
        case 'd':
            System.out.println("Salir");
            break;
        default:
            System.out.println("Opcion incorrecta");
}}while(menu!='d');
    }
    
}
