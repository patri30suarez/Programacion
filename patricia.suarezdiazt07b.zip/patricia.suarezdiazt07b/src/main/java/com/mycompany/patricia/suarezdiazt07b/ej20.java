/*
 Diseñar una clase Factura que consta de:
 Número identificador: lo proporciona el usuario en el alta de la factura.
 Fecha de la factura: la toma del sistema en el momento del alta.
 Número de cliente: : lo proporciona el usuario en el alta de la factura.
 Porcentaje de IVA: 21% para todas las facturas.
 Un número indeterminado de lineaFactura que contienen:
 Descripción del producto
 Precio unitario
 Cantidad de unidades
 Porcentaje de descuento: 5% para líneas con más de 10 unidades.
 Importe total de la línea.
 Importe total: inicialmente cero, y se va actualizando siempre que se añadan/eliminen líneas.
Implementar la clase con su constructor y métodos para añadir línea de factura, eliminar línea de factura y mostrar
la factura por consola. Te hará falta una clase lineaFactura con su constructor.
Para añadir línea de factura, habrá que solicitar al usuario los campos necesarios para añadirlo (descripción, precio
unitario y cantidad de unidades). Para eliminar una línea, solicitaremos el número de línea.
Hacer también un programa con un menú para gestionar una factura (alta, añadir/eliminar líneas, mostrar factura)
Nota: pensar en método toString() para líneaFactura.
 */
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Scanner;

public class ej20 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        ArrayList<Factura> facturas = new ArrayList<>();
        char menu1 = '0';
        char menu2 = '0';
        int idFac = 0;
        int idCli = 0;
        boolean IDRep = false;
        int numFac = 0;
        int menuFac = 0;
        boolean busFac = false;
        String descrip = new String();
        float precio = 0;
        int cant = 0;
        int eliminar = 0;
        float total = 0;
        do {

            System.out.println("Â¿Que desea hacer?");
            System.out.println("a.Dar de alta una factura");
            System.out.println("b.Añadir/eliminar li­neas");
            System.out.println("c.Mostrar facturas");
            System.out.println("s.Salir");
            menu1 = t.nextLine().charAt(0);

            switch (menu1) {

                case 'a':
                    IDRep = false;
                    System.out.println("Introduce la factura");
                    idFac = t.nextInt();
                    t.nextLine();
                    System.out.println("Introduce el cliente");
                    idCli = t.nextInt();
                    t.nextLine();
                    for (Factura i : facturas) {
                        if (i.ID== idFac) {
                            IDRep = true;
                        }
                    }
                    if (!IDRep) {
                        Factura factura = new Factura(idFac, idCli);
                        facturas.add(factura);
                    } else {
                        System.out.println("Ya se usa esa factura");
                    }
                    break;

                case 'b':
                    busFac = false; 
                    System.out.println("Guardar");
                    if (facturas.size() == 0) {
                        System.out.println("No hay facturas");
                    } else {
                        for (int i = 0; i < facturas.size(); i++) {
                            System.out.println("Factura " + (i + 1) + " identificador " + facturas.get(i).ID);
                        }
                       
                        do {
                            System.out.println("Introduce la factura");
                            idFac = t.nextInt();
                            t.nextLine();
                            for (int i = 0; i < facturas.size(); i++) {
                                if (facturas.get(i).ID == idFac) {
                                    busFac = true;
                                    numFac = i;
                                }
                            }
                            if (!busFac) {
                                System.out.println("Factura incorrecta");
                                System.out.println("¿Desea con continuar? 1.Si 2.No");
                                menuFac = t.nextInt();
                                t.nextLine();
                                if (menuFac == 1) {
                                    busFac = false;
                                }
                                if (menuFac == 2) {
                                    busFac = true;
                                }
                            }
                        } while (!busFac);

                        do {
                            System.out.println("¿Que desea hacer?");
                            System.out.println("a. Añadir Linea");
                            System.out.println("b. Eliminar Linea");
                            System.out.println("c. Salir");
                            menu2 = t.nextLine().charAt(0);
                            switch (menu2) {

                                case 'a':
                                    System.out.println("Introduce la descripcion");
                                    descrip = t.nextLine();
                                    System.out.println("Introduce el precio");
                                    precio = t.nextFloat();
                                    t.nextLine();
                                    System.out.println("Introduce las catidades");
                                    cant = t.nextInt();
                                    t.nextLine();
                                    lineaFactura linea = new lineaFactura(descrip, precio, cant);
                                    facturas.get(numFac).lineas.add(linea);
                                    break;

                                case 'b':
                                    if (facturas.get(numFac).lineas.size() == 0) {
                                        System.out.println("No tiene lineas");
                                    } else {
                                        System.out.println("Estas son las linea");
                                        for (int i = 0; i < facturas.get(numFac).lineas.size(); i++) {
                                            System.out.println("Linea " + (i + 1) + " Descripcion: " + facturas.get(numFac).lineas.get(i).descrip);
                                        }
                                        System.out.println("Que linea quiere eliminar");
                                        eliminar = t.nextInt();
                                        t.nextLine();
                                        eliminar = eliminar - 1;
                                        facturas.get(numFac).lineas.remove(eliminar);
                                        System.out.println("Linea eliminada");

                                    }
                                    break;

                                case 'c':
                                    System.out.println("Salir");
                                    break;
                            }
                        } while (menu2 != 'c');
                    }
                    break;
                case 'c':
                    System.out.println("Facturas");
                    for (int i = 0; i < facturas.size(); i++) {
                        total = facturas.get(i).totalFactura();
                        System.out.println("Factura " + (i + 1) + " identificador " + facturas.get(i).ID);
                        System.out.println("Fecha : " + facturas.get(i).fecha.toString() + " Identificador del cliente: " + facturas.get(i).numCliente);
                        System.out.println("El valor total es " + total);
                        if (facturas.get(i).lineas.size() == 0) {
                            System.out.println("Esta factura no tiene lineas");
                        } else {
                            System.out.println("Esta factura tiene las lineas");
                            for (int j = 0; j < facturas.get(i).lineas.size(); j++) {
                                System.out.println(facturas.get(i).lineas.get(j).toString());
                            }
                        }
                        System.out.println("");
                    }
                    break;
                case 's':
                    System.out.println("Salir");
                    break;
            }
        } while (menu1 != 's');
    }

}


