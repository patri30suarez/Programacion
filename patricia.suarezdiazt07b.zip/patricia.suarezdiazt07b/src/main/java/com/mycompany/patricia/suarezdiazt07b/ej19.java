/*
Realizar una clase carritoCompra2 que mantenga las compras realizadas por un cliente en un
ArrayList. Cada posición del ArrayList contendrá el código del producto, la descripción, el precio unitario y la
cantidad de unidades compradas y el precio total de ese producto (cantidad x precio unitario). Se permite comprar
un número indeterminado de artículos. Además de la lista de productos, la clase tiene el importe total de la compra,
que debe estar siempre actualizado. Necesitamos los métodos:
a) Mostrar por consola el estado actual del carrito.
b) Vaciar carrito.
c) Añadir producto.
d) Eliminar producto (se le pasa el código de producto) y lo elimina físicamente del ArrayList.
Hacer un programa con un menú que permita al usuario operar con el carrito de la compra */

package com.mycompany.patricia.suarezdiazt07b;

import java.util.Scanner;

public class ej19 {
    public static void main(String[] args) {
    Scanner t = new Scanner(System.in);
    char op = '0';
    int cod = 0;
    String descrip;
    float precioUnidad;
    int cant;
    float precioTotal;
    Producto articulo = new Producto();
    carritoCompra2 carrito = new carritoCompra2();
    boolean eliminar = false;
    
    
    
        do{
            System.out.println("a.Mostrar");
            System.out.println("b.Vaciar");
            System.out.println("c.Añadir");
            System.out.println("d.Eliminar");
            System.out.println("e.Salir");
            op = t.nextLine().charAt(0);
            switch(op){
                case 'a':
                    for (int i = 0; i < carrito.carrito.size(); i++) {
                        System.out.println("Producto "+(i+1));
                        System.out.println("Codigo"+carrito.carrito.get(i).cod);
                        System.out.println("Descripcion "+carrito.carrito.get(i).descrip);
                        System.out.println("Precio "+carrito.carrito.get(i).precioUnidad);
                        System.out.println("Unidades "+carrito.carrito.get(i).cantidad);                        
                    }
                    precioTotal = carrito.total();
                    System.out.println("Importe total "+precioTotal);
                    break;
                case 'b':
                    System.out.println("Vaciar");
                    carrito.vaciar();
                    break;
                case 'c':
                    System.out.println("Introduce el codigo");
                    cod = t.nextInt();
                    t.nextLine(); //error con salto de carro
                    System.out.println("Introduce la descripcion");
                    descrip = t.nextLine();
                    System.out.println("Introduce el precio");
                    precioUnidad = t.nextFloat();
                    System.out.println("Introduce las unidades");
                    cant = t.nextInt();
                    articulo = new Producto(cod,descrip,precioUnidad,cant);
                    carrito.añadir(articulo);
                    t.nextLine(); 
                    break;
                case 'd':
                    System.out.println("Introduce el codigo para eliminar");
                    cod = t.nextInt();
                    t.nextLine();
                    eliminar = carrito.eliminar(cod);
                    if(eliminar) System.out.println("Eliminado");
                    else System.out.println("No se encuentra");
                    break;
                case 'e':
                    System.out.println("Salir");
                    break;
                default: System.out.println("Opcion incorrecta");
            }
            
        }while (op!='e');
    }
}
