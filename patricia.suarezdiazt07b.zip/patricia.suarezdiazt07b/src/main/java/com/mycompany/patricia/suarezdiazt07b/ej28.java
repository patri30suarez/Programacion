/*
Sobre el siguiente código, modifica la clase Contacto para que funcione el main() mostrado:
import java.time.*;
public class ejercicio {
public static void main(String[] args) {
Contacto [] agenda = new Contacto [10];
agenda [0] = new Contacto ("Marta", 6661111222L, LocalDate.parse("2019-11-25"));
agenda [1] = new Contacto ("Miguel", 1111111L, LocalDate.now());
agenda [2] = new Contacto ("Ana", 3333333L,"2019-11-20");
agenda [3] = new Contacto ("Daniel", 444444L);
}}
class Contacto {
 public String nombre;
 public long numero;
 public LocalDate fechaAltaAgenda;
 Contacto (String no, long nu,LocalDate fe){
 this.nombre = no;
 this.numero = nu;
 this.fechaAltaAgenda = fe;
 }
}
 */
package com.mycompany.patricia.suarezdiazt07b;

import java.time.LocalDate;

public class ej28 {
    public static void main(String[] args) {
Contacto [] agenda = new Contacto [10];
agenda [0] = new Contacto ("Marta", 6661111222L, LocalDate.parse("2019-11-25"));
agenda [1] = new Contacto ("Miguel", 1111111L, LocalDate.now());
agenda [2] = new Contacto ("Ana", 3333333L,"2019-11-20");
agenda [3] = new Contacto ("Daniel", 444444L);
    }
    
}
