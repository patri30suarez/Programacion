package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;

public class carritoCompra2 {
    
ArrayList<Producto> carrito = new ArrayList<>();


public void añadir (Producto articulo){
    carrito.add(articulo);
} 
public float total(){
    float cont = 0;
    for (int i = 0; i < carrito.size(); i++) {
        cont += carrito.get(i).precioTotal;
    }
    return cont;
}
public void vaciar(){
    carrito.clear();
}

public boolean eliminar(int cod){
    boolean encon = false;
    for (int i = 0; i < carrito.size() && !encon; i++) {
        if(carrito.get(i).cod == cod){
            encon = true;
            carrito.remove(i);
        }
    }
    return encon;
}
}

