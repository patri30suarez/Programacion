
package com.mycompany.patricia.suarezdiazt07b;

public class lineaFactura {
     String descrip = new String();
  float precioUnidad = 0f;
  int cant = 0;
  float descuento = 0f;
  float importeTotal = 0f;
  
  public lineaFactura(){
  }
  public lineaFactura(String descrip, float precio, int cant){
      this.descrip = descrip;
      this.precioUnidad = precio;
      this.cant = cant;
      if (cant > 10) this.descuento = 0.05f;
      else this.descuento = 0;
      this.importeTotal = (precio * cant) - (precio * cant) * this.descuento;
      
  }
  public String toString(){
      String factura = new String();
      StringBuilder constructor = new StringBuilder();
      constructor.append("Descripcion: ");
      constructor.append(this.descrip);
      constructor.append(" | precio ");
      constructor.append(this.precioUnidad);
      constructor.append(" | cantidad ");
      constructor.append(this.cant);
      constructor.append(" |Importe total: ");
      constructor.append(this.importeTotal);
      factura = constructor.toString();
      return factura;
  }
}

