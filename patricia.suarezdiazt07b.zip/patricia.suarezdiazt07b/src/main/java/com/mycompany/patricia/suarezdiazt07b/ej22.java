
/*Realizar un programa que genere 10.000 números aleatorios entre 1 y 6 (como si fuese lanzar un dado).
Guarda los resultados obtenidos, esto es, cuantas veces ha salido el uno, cuantas veces ha salido el dos, etc… para
finalmente mostrar la diferencia de veces entre el número que más ha salido y el que menos ha salido.
     */
package com.mycompany.patricia.suarezdiazt07b;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class ej22 {

    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<>();
        Random r = new Random();
        Integer num;
        ArrayList<Integer> cont = new ArrayList<>();
        int diferencia;
        for (int i = 0; i < 10000; i++) {
            num = (Integer)r.nextInt(6)+1;
            numeros.add(num);
        }
        Collections.sort(numeros);

        num = (Integer) 1;
        cont.add(Collections.frequency(numeros, num));
        num = (Integer) 2;
        cont.add(Collections.frequency(numeros, num));
        num = (Integer) 3;
        cont.add(Collections.frequency(numeros, num));
        num = (Integer) 4;
        cont.add(Collections.frequency(numeros, num));
        num = (Integer) 5;
        cont.add(Collections.frequency(numeros, num));
        num = (Integer) 6;
        cont.add(Collections.frequency(numeros, num));
        
        for (int i = 0; i < cont.size(); i++) {
            System.out.println("Del "+(i+1)+" hay "+cont.get(i)+" repeticiones");
        }
        
        Collections.sort(cont);
        diferencia = cont.get(cont.size()-1)-cont.get(0);
        System.out.println("La diferencia entre el numero que mas ha salido y el que menos es "+diferencia);
    }
    
}
