package com.mycompany.patricia.suarezdiazt07b;


public class Producto {
     int cod;
    String descrip = new String();
    float precioUnidad;
    int cantidad;
    float precioTotal;
    
    public Producto(){
        
    }
    
    public Producto(int codigo, String descrip, float precio, int cant){
        this.cod = codigo;
        this.descrip = descrip;
        this.precioUnidad = precio;
        this.cantidad = cant;
        this.precioTotal = this.precioUnidad * this.cantidad;
    }
}

