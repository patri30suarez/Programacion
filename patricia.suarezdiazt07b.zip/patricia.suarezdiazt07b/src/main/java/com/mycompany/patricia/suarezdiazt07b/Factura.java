
package com.mycompany.patricia.suarezdiazt07b;

import java.time.LocalDate;
import java.util.ArrayList;

public class Factura {
     int ID = 0;
    LocalDate fecha = LocalDate.now();
    int numCliente = 0;
    final float IVA = 0.21f;
    ArrayList<lineaFactura> lineas = new ArrayList<>();
    float importeTotal = 0;
    
    
    public Factura(int ID, int numCliente){
        this.ID = ID;
        this.fecha = LocalDate.now();
        this.numCliente = numCliente;
        
    }
    public float totalFactura (){
        float total = 0f;
        for (int i = 0; i < lineas.size(); i++) {
        total += lineas.get(i).importeTotal;
        }
        total = total + total*IVA;
        return total;
    }
}

