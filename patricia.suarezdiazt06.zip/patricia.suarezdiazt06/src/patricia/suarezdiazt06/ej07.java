/* Implementar una clase llamada Circulo, que tiene solo la propiedad radio y los métodos
setRadio, getRadio, calcularCircunferencia, calcularSuperficie, calcularDiametro además de un
constructor. Crea un programa que use esta clase creando un par de círculos y usando los métodos
creados. ¿El atributo radio puede ser privado?.*/

package patricia.suarezdiazt06;

import java.util.Scanner;

public class ej07 {

    public static void main(String[] args) {
    Scanner t = new Scanner(System.in);
    Circulo c1 = new Circulo(0);
int menu;
boolean continuar = true;
float radio;
        do{
        System.out.println("Introduce el radio");
        radio = t.nextFloat();
        c1.setRadio(radio);
        System.out.println("Esta es la Circunferencia" +c1.calcularCircunferencia());
        System.out.println("Esta es la superficie"+c1.calculaeSuperficie());
        System.out.println("Este es el diametro"+c1.calcularDiametro());
        System.out.println("Este es el radio "+c1.getRadio());
        System.out.println("¿Desea continuar (Pulse 1 para continuar)");
        menu=t.nextInt();
        if (menu != 1){
      continuar = false;}
        }while(continuar);
    }
}