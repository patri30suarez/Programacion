package patricia.suarezdiazt06;

public class Circulo {

    private float radio;

    public Circulo(float r) {
        this.radio = r;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public double calcularCircunferencia() {
        double circunferencia;
        circunferencia = (double) (this.radio * 2 * Math.PI);
        return circunferencia;
    }

    public double calculaeSuperficie() {
        double superficie;
        superficie = (double) (this.radio * this.radio * Math.PI);
        return superficie;
    }

    public double calcularDiametro() {
        double diametro;
        diametro = (double) (2 * this.radio);
        return diametro;
    }
}
