/*A partir de la clase CuentaCorriente que te proporcionará el profesor, crea un programa en
el que se creen una cuenta corriente (siempre se crean con saldo inicial cero) y mediante un menú le
permita al usuario hacer operaciones como ingresar, retirar y consultar saldo en la cuenta. El único
atributo público de la cuenta es el IBAN (String de 24 dígitos/letras). Otros atributos privados son saldo,
contadorIngresos, porcentajeComision y minimoComision, pero como son privados, no tenemos acceso a ellos. Los
métodos son:
- constructor (String Iban): se le pasa el nombre de la cuenta y fija saldo inicial a cero.
- void ingresar (float importe): aumenta el saldo. Si se hacen 3 ingresos consecutivos, sin ninguna retirada en
medio, se regala 0,7 euros al usuario.
- boolean retirar (float importe): reduce el saldo si es posible, no puede quedar negativo (devuelve si se ha
efectuado la retirada o no). Cada retirada tiene una comisión asociada.
- float getSaldo (): devuelve el saldo actual en la cuenta.
- setComision (float porcentaje, float impMinimo). Fija la comisión de retirada, para todas las cuentas.
- getPorcentajeComision() devuelve un float con el porcentaje de comisión a aplicar en retiradas.
- getMinimoComision() devuelve un float con el importe mínimo de comisión a aplicar en retiradas
 */
package patricia.suarezdiazt06;

import java.util.Scanner;

public class ej03 {

      public static void main(String[] args) {
    Scanner t = new Scanner(System.in);
    String IBAN = new String();
    float porcentaje=0, porcentaje1=0, impMinimo=0, impMinimo1=0, saldo, importe;
    boolean salir = false;
    System.out.println("Introduce el porcentaje");
    porcentaje = t.nextFloat();
    System.out.println("Introduce la comisión mínima del banco");
    impMinimo = t.nextFloat();
    t.nextLine();
    System.out.println("Introduce el Iban de la cuenta");
    CuentaCorriente.setComision(porcentaje, impMinimo);
    IBAN = t.nextLine();
    CuentaCorriente c1 = new CuentaCorriente(IBAN);
     int opcion;
        do {
           opcion=pintarMenu ();
           switch (opcion) {
               case 1: saldo = c1.getSaldo();
                       System.out.println("Su saldo es "+saldo);
                       break;
               case 2: System.out.println("Introduce la cantidad para ingresar");
                       importe = t.nextFloat();
                       c1.ingresar(importe);
                       t.nextLine();
                       break;
               case 3: System.out.println("Introduce la cantidad para retirar");
                       importe = t.nextFloat();
                       if(c1.retirar(importe)){System.out.println("Su dinero se ha retirado correctamente");}
                       else System.out.println("Saldo insuficiente");
                       t.nextLine();
                       break;   
               case 4: porcentaje1=CuentaCorriente.getPorcentajeComision();
                       System.out.println("Su comision actual es "+porcentaje1);
                       break;    
               case 5: impMinimo1=CuentaCorriente.getMinimoCosmision();
                       System.out.println("La comisión minima que del banco es "+impMinimo1);
                       break;    
               case 0: salir=true; break;    
               default: System.out.println("Opción incorrecta");
            }
        } while (!salir);
    }
    
       private static int pintarMenu (){
      Scanner t = new Scanner(System.in);
      System.out.println("\n\n");  
      System.out.println("Elija una opción:");  
      System.out.println("1 Consultar Saldo");  
      System.out.println("2 Ingresar");  
      System.out.println("3 retirar");  
      System.out.println("4 pedir el porcentaje de comision");  
      System.out.println("5 Pedir la comisión mínima que cobrará el banco");  
      System.out.println("0 Salir");  
      try {                  //si introduce un valor no entero haría return 999
        return Integer.parseInt (t.nextLine());
      } catch (Exception e ) {return 999;}
   }
    
}
