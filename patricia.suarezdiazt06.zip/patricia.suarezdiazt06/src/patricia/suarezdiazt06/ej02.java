/*A partir de la clase MovilPrepago del ejercicio anterior, crea un programa en el que el
usuario dé de alta un teléfono con unas características determinadas y luego le permita mediante un
menú hacer operaciones como consultar saldo, recarga, hacer llamada, navegar. Se proporciona un
modelo (modeloMenu) a modo de esqueleto, con el menú y las funciones necesarias, en las que solo
tienes rellenar los huecos
 */
package patricia.suarezdiazt06;

import java.util.Scanner;


  

public class ej02 {
 static Scanner teclado;
    public static void main(String[] args) {
    
        boolean salir =false;
           teclado = new Scanner(System.in);
 int recarga=0, segundos=0, navegar=0;
        long movil;
        float costeEstablecimientoLlamada, costeMinutoLlamada,costeConsumoMB, saldo;
        System.out.println("Introduce el numero de telefonno");
        movil= teclado.nextLong();
        System.out.println("Introduce el coste de establecimiento de llamada");
        costeEstablecimientoLlamada = teclado.nextFloat();
        System.out.println("Introduce el coste del minuto por llamada");
        costeMinutoLlamada = teclado.nextFloat();
        System.out.println("Introduce el coste de MB navegado");
        costeConsumoMB = teclado.nextFloat();
        System.out.println("Introduce el saldo del movil");
        saldo = teclado.nextFloat();
        MovilPrepago p1 = new MovilPrepago(movil,costeEstablecimientoLlamada,costeMinutoLlamada,costeConsumoMB,saldo);
        int opcion;
        do {
           opcion=pintarMenu ();
           switch (opcion) {
               case 1: System.out.println(p1.consultarSaldo());break;
               case 2: System.out.println("Introduce el saldo para recargar (debe ser multiplo de 5)");
                       recarga = teclado.nextInt();
                       p1.recargar(recarga);
                       teclado.nextLine();
                       break;
               case 3: System.out.println("Introduce la duración de llamada"); 
                       segundos = teclado.nextInt();
                       p1.efectuarLlamada(segundos);
                       teclado.nextLine();
                       break;   
               case 4: System.out.println("Introduce el tiempo de navegar"); 
                        navegar = teclado.nextInt();
                        p1.navegar(navegar);
                        teclado.nextLine();
                        break;    
               case 0: salir=true; break;    
               default: System.out.println("Opción incorrecta");
            }
        } while (!salir);
    }  // fin main    
    
   private static int pintarMenu (){
      System.out.println("\n\n");  
      System.out.println("Elija una opción:");  
      System.out.println("1 Consultar Saldo");  
      System.out.println("2 Recarga");  
      System.out.println("3 Hacer llamada");  
      System.out.println("4 Navegar");  
      System.out.println("0 Salir del programa");  
      try {                  //si introduce un valor no entero haría return 999
        return Integer.parseInt (teclado.nextLine());
      } catch (Exception e ) {return 999;}
   }
    
    
}
