/*Haz un programa como el anterior, pero creando dos cuentas en vez de una. Habrá una
opción de menú nueva que será “Cambiar cuenta activa” para pasar de una cuenta a otra.
Tendremos una variable de tipo CuentaCorriente que le puedes llamar cuentaActiva que unas veces
apuntará a una cuenta y otras veces a la otra
Recuerda que las variables de tipo Objeto, a diferencia de los tipos primitivos, son apuntadores a
los objetos, si tenemos los objetos ‘cuenta1’ y ‘cuenta2’ creados con su constructor, podemos hacer
luego una tercera variable ‘cuentaActiva’ sin constructor y hacer ‘cuentaActiva=cuenta1’ o bien
‘cuentaActiva=cuenta2’ cuando nos interese.
 */
package patricia.suarezdiazt06;

import java.util.Scanner;

public class ej04 {

    public static void main(String[] args) {
    Scanner t = new Scanner(System.in);
    String IBAN = new String();
    float porcentaje=0, porcentaje1=0, impMinimo=0, impMinimo1=0, saldo, importe;
    boolean salir = false;
    int cuenta = 1;
    CuentaCorriente cuenta1 = new CuentaCorriente("");
    CuentaCorriente cuenta2 = new CuentaCorriente("");
    CuentaCorriente activa = new CuentaCorriente("");
    System.out.println("Introduce el porcentaje");
    porcentaje = t.nextFloat();
    System.out.println("Introduce la comisión mínima del banco");
    impMinimo = t.nextFloat();
    t.nextLine();
    CuentaCorriente.setComision(porcentaje, impMinimo);
    System.out.println("Introduce el Iban de la primera cuenta que quiere abrir");
    IBAN = t.nextLine();
    cuenta1 = new CuentaCorriente(IBAN);
    activa = cuenta1;
    System.out.println("Introduce el Iban de la segunda cuenta que quiere abrir");
    IBAN = t.nextLine();
    cuenta2 = new CuentaCorriente(IBAN);
    int opcion;
        do {
           opcion=pintarMenu ();
           switch (opcion) {
               case 1: saldo = activa.getSaldo();
                       System.out.println("Su saldo actual es "+saldo);
                       break;
               case 2: System.out.println("Introduce la cantidad para ingresar");
                       importe = t.nextFloat();
                       activa.ingresar(importe);
                       t.nextLine();
                       break;
               case 3: System.out.println("Introduce el saldo que desea retirar");
                       importe = t.nextFloat();
                       if(activa.retirar(importe)){System.out.println("Su saldo se ha retirado correctamente");}
                       else System.out.println("Saldo insuficiente");
                       t.nextLine();
                       break;   
               case 4: porcentaje1=CuentaCorriente.getPorcentajeComision();
                       System.out.println("Su comision actual es "+porcentaje1);
                       break;    
               case 5: impMinimo1=CuentaCorriente.getMinimoCosmision();
                       System.out.println("La comisión minima que solicita el banco para retirar dinero es "+impMinimo1);
                       break;
               case 6:System.out.println("Introduce el numero de cuenta que quiere empezar a manejar (1/2)");
                      cuenta = t.nextInt();
                      if (cuenta == 1){activa = cuenta1;}
                      else if (cuenta ==2){activa = cuenta2;}
                      else{System.out.println("Dato introducido incorrecto se mantendrá la cuenta activa hasta el momento");}
                      break;
               case 0: salir=true; break;    
               default: System.out.println("Opción incorrecta");
            }
        } while (!salir);
    }
    
        private static int pintarMenu (){
      Scanner t = new Scanner(System.in);
      System.out.println("\n\n");  
      System.out.println("Elija una opción:");  
      System.out.println("1 Consultar Saldo");  
      System.out.println("2 Ingresar");  
      System.out.println("3 retirar");  
      System.out.println("4 pedir el porcentaje de comision");  
      System.out.println("5 Pedir la comisión mínima que cobrará el banco");  
      System.out.println("0 Salir");  
      try {                  //si introduce un valor no entero haría return 999
        return Integer.parseInt (t.nextLine());
      } catch (Exception e ) {return 999;}
   }
    
}
