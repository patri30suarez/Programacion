/*A partir de la clase Ahorcado que te proporcionará el profesor, crea un programa que permita
al usuario jugar al ahorcado. Desconocemos los atributos de la clase Ahorcado ya que son privados,
pero sus métodos públicos son:
- Constructor(String txtAdivinar, String txtPista). Crea el juego con la frase a adivinar y con un texto de pista
para el jugador.
- Constructor(String txtAdivinar). Crea el juego con la frase a adivinar, sin pistas.
- boolean probarLetra (char x). Comprueba si la letra pasada como parámetro está en la frase a adivinar, en
caso afirmativo, devuelve true¸ sino false.
- boolean adivinada(). Devuelve true si se ha adivinado la frase, false en caso contrario.
- boolean perdio(). Devuelve true si se ha llegado al número máximo de intentos sin adivinar la frase, false en
caso contrario.
- char leerLetra (). Pide al usuario por consola una letra y devuelve dicha letra.
- void pintar (). Dibuja un “tablero” en la consola, con el estado del juego.
 */
package patricia.suarezdiazt06;

import java.util.Scanner;

public class ej05 {
public static void main(String[] args) {
Scanner t = new Scanner(System.in);
String adivinar = new String();
String pista = new String();
boolean continuar = true;
char letra;
        System.out.println("Introduzca la frase a adivinar (en minusculas)");
        adivinar = t.nextLine();
        System.out.println("Introduce la pista");
        pista = t.nextLine();
Ahorcado j1 = new Ahorcado(adivinar,pista);
if(pista.equals("")){System.out.println("Juego sin pistas");}
else{System.out.println("La pista es "+pista);}
do{
    letra=j1.leerLetra();
    if(j1.probarLetra(letra)){
        System.out.println("Correcto");
    }
    else{
        System.out.println("Incorrecto");
    };
    j1.pintar();
    if(j1.adivinada()){
        System.out.println("Has adivinado");
        continuar =false;
    }else{
       j1.pintar(); 
    }
}while(continuar && !j1.perdio());
if(j1.perdio()==true){
    System.out.println("Te han ahorcado");
}
    }
    
}
