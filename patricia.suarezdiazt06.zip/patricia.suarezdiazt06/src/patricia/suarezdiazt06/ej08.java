/* Implementar una clase llamada EjemplarLibro que se va a usar en una biblioteca y que tiene
los siguientes atributos:
- Título de libro (se le pone en el momento del alta)
- Fecha de adquisición (es la fecha del sistema en el momento del alta)
- Número de ejemplar: 1, 2, 3, etc. (de un mismo libro, la biblioteca tiene varios ejemplares)
- Prestado (sí /no). Inicialmente no está prestado.
Además, tiene los siguientes métodos:
- Constructor 1: cuando es el primer ejemplar de un determinado título, se le pasa como parámetro solo el título
del libro. El resto de datos los puede calcular él.
- Constructor 2: se le pasa como parámetro un libro y copia todos sus atributos salvo el número de ejemplar
que será 1 más el del libro pasado.
- Prestar (): si no está prestado lo marca como prestado y devuelve true¸ si está prestado no hace nada y
devuelve false.
- Devolver (): si está prestado lo marca como no prestado y devuelve true¸ si no está prestado no hace nada y
devuelve false.
- toString (): Genera un String con el nombre, la fecha entre paréntesis y el número de ejemplar entre corchetes.
Este método se usará para sacar por pantalla de forma cómoda los datos de un libro.
Haz un main() que cree 4 libros (probando ambos constructores), que realice algún préstamo y
devolución, y finalmente muestre los libros -con toString()-. */

package patricia.suarezdiazt06;

import java.util.Scanner;

public class ej08 {

    public static void main(String[] args) {
    Scanner t = new Scanner(System.in);
   String titulo1;
        String titulo2;
        String titulo3;
        String titulo4;
        int numero;
        boolean menu = true;
        System.out.println("Introduce el Titulo del primer libro");
        titulo1 = t.nextLine();
        EjemplarLibro L1 = new EjemplarLibro(titulo1);
        System.out.println("Introduce el Titulo del segundo  libro");
        titulo2 = t.nextLine();
        EjemplarLibro L2 = new EjemplarLibro(titulo2);
        System.out.println("Introduce el titulo del tercer libro");
        titulo3 = t.nextLine();
        EjemplarLibro L3 = new EjemplarLibro(titulo3);
        System.out.println("Introduce el titulo del cuarto libro");
        titulo4 = t.nextLine();
        EjemplarLibro L4 = new EjemplarLibro(titulo4);
        EjemplarLibro Activo = new EjemplarLibro(L1);
        do {
            System.out.println("Elija un Libro 1 2 3 o 4:");
            numero = t.nextInt();
            switch (numero) {
                case 1:
                    Activo = L1;
                    break;
                case 2:
                    Activo = L2;
                    break;
                case 3:
                    Activo = L3;
                    break;
                case 4:
                    Activo = L4;
                    break;
            }
            System.out.println("1 Prestar");
            System.out.println("2 Devolver");
            System.out.println("3 Info");
            System.out.println("4 Salir");

            numero = t.nextInt();
            switch (numero) {
                case 1:
                    if (Activo.Prestar()) {
                        System.out.println("Aqui tienes el libro");
                    } else {
                        System.out.println("Ejemplar no disponible");
                    }
                    break;
                case 2:
                    if (Activo.Devolver()) {
                        System.out.println("Gracias por devolver el libro");
                    } else {
                        System.out.println("Ya estaba disponible");
                    }

                    break;
                case 3:
                    System.out.println(Activo.toString());
                    break;
                case 4:
                    menu = false;
                    break;
            }

        } while (menu);

    }

}