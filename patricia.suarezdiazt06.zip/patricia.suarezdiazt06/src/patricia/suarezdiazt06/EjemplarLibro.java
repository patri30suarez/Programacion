package patricia.suarezdiazt06;

import java.util.Date;

public class EjemplarLibro {

    public String titulo;
    public String fecha;
    public boolean prestado;
    public int numeroEjemplares;

    public EjemplarLibro(String str) {
        titulo = str;
        java.util.Date contenedor = new Date();
        fecha = contenedor.toString();
        prestado = false;
        numeroEjemplares = 1;
    }

    public EjemplarLibro(EjemplarLibro L1) {
        this.titulo = L1.titulo;
        this.fecha = L1.fecha;
        this.numeroEjemplares = L1.numeroEjemplares + 1;
        this.prestado = false;
    }

    public boolean Prestar() {
        boolean noPrestado;
        if (this.prestado == false) {
            noPrestado = true;
            this.prestado = true;
            return noPrestado;
        } else {
            noPrestado = false;
            return noPrestado;
        }
    }

    public boolean Devolver() {
        boolean Prestado;
        if (this.prestado == false) {
            Prestado = false;
            return Prestado;
        } else {
            this.prestado = false;
            Prestado = true;
            return Prestado;
        }
    }

    public String toString() {
        StringBuilder todo = new StringBuilder();
        todo.append("Título " + this.titulo + " ");
        todo.append("Fecha (" + this.fecha + ") ");
        todo.append("Número de ejemplar " + this.numeroEjemplares );

        return todo.toString();
    }
}

