
package patricia.suarezdiazt05;

import java.util.Scanner;

/*Un número primo es aquel que solo tiene como divisores el número 1 y a él mismo. Usando la función
del programa anterior, haz un programa que muestre la suma de los números primos comprendidos entre 1 y 1000. */
public class ej07 {
    
public static void main(String[] args) {
    int num = 0;
    int num2 = 0;
    int div=0;
    int div2=0;
    Scanner t = new Scanner(System.in);    
    System.out.println("Introduce un número entero positivo");
    num = t.nextInt();
    System.out.println("Introduce otro número entero positivo");
    num2 = t.nextInt();
    div=calcularDivisores(num);
    div2=calcularDivisores(num2);
    if (div>div2)System.out.println(" El número con más divisores es"+num);
    else if (div2>div)System.out.println(" El número con más divisores es"+num2);
    else System.out.println("Tienen el mismo número de divisores");
    }
    public static int calcularDivisores(int num){
        int cont = 0;
        int decre = num;
        if(num<=0) return 0;
        while (decre>0){
            if(num%decre==0) cont++;
            decre--;
        }
        return cont;
    }
}

