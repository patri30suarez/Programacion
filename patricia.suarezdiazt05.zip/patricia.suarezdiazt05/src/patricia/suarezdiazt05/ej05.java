
package patricia.suarezdiazt05;

import java.util.Scanner;

/*Programa que calcule el factorial de números menores de 20. El programa permite al usuario meter los
números que desee y finalizará cuando meta un número menor que 1 o mayor que 20. Crea las funciones que
consideres útiles y que puedas reutilizar en otros programas. */
public class ej05 {
    
public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
    int num = 1;
    double fact;
    System.out.println("Si introduce un número menor que 1 o mayor que 20 el programa finaliza ");
    while(num>0&&num<21){
        System.out.println("Introduce un número ");
        num = t.nextInt();
        if(num>0&&num<21){
            fact=factorial(num);
            System.out.println("El factorial de "+num+" es "+fact);
        }
    }
    }
    public static double factorial(int num){
        double cont = num;
        for (int i = num-1; i >1 ; i--) {
            cont *= i;
        }
        return cont;
    }
}

