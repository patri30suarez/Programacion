
package patricia.suarezdiazt05;

import java.util.Scanner;

public class ej02 {
    /* Programa que presente un menú y permita calcular repetidas veces a) el área de círculo –necesitará el
radio- , b) el área de cuadrado –necesitará el lado - , c) el área de triángulo –necesitará base y altura – d) Salir. Usar
funciones para cada una de las 3 opciones.*/
    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        char opcion;
        double n = 0;
        double n1 =0; 
        double n2 = 0;
        boolean pas = true;
        while(pas){
        System.out.println("Seleccione la opcion deseada");
        System.out.println("a: el área de un circulo");
        System.out.println("b: el área de un cuadrado");
        System.out.println("c: el área de un triángulo");
        System.out.println("d: Salir");
        opcion = t.nextLine().charAt(0);
        switch(opcion){
            case 'a':
                System.out.println("Introduce el radio ");
                n = t.nextDouble();
                n1 = circulo(n);
                System.out.println("El área del círculo es "+n1);
                t.nextLine();
                break;
            case 'b':
                System.out.println("Introduce el lado ");
                n = t.nextDouble();
                n1 = cuadrado(n);
                System.out.println("El área del cuadrado es "+n1);
                t.nextLine();
                break;
                
            case 'c':
                System.out.println("Introduce la base");
                n = t.nextDouble();
                System.out.println("Introduce la altura");
                n1 = t.nextDouble();
                n2 = triangulo(n,n1);
                System.out.println("El área del triángulo es "+n2);
                t.nextLine();
                break;
            case 'd':
                System.out.println("Fin");
                pas = false;
                break;
                
        }
                
        }
    }
    public static double circulo(double radio){
        double area = Math.PI * radio * radio; 
        return area;
    }
    
    public static double cuadrado(double lado){
        double area = lado*lado; 
        return area;
    }
    
    public static double triangulo(double base,double altura){
        double area = base*altura/2; 
        return area;
    }
}
