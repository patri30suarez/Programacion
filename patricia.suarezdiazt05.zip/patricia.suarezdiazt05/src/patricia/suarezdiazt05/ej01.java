package patricia.suarezdiazt05;

import java.util.Scanner;

public class ej01 {
 public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        
        //apartado a 
        int num = 0;
        System.out.println("introduce un número entero");
        num = t.nextInt();
        if(par(num)) System.out.println("Es par");
        else System.out.println("Es impar");
        
        // apartado b
        double n = 0;
        double n2 = 0;
        double n3 = 0;
        double mayor = 0;
        System.out.println("introduce un número");
        n = t.nextDouble();
        System.out.println("introduce otro número");
        n2 = t.nextDouble();
        System.out.println("introduce otro número entero");
        n3 = t.nextDouble();
        mayor = mayor(n,n2,n3);
        System.out.println("El mayor es "+mayor);
        
        //apartado c
        long num1 = 0;
        long num2 = 0;
        long suma = 0;
        System.out.println("introduce un número positivo");
        num1 = t.nextLong();
        System.out.println("introduce un número mayor que el anterior");
        num2 = t.nextLong();
        suma = sumaIntervalo(num1,num2);
        if(suma== -1) System.out.println("Has introducido mal los números");
        else System.out.println("La suma del intervalo es "+suma);
        
        // apartado d
        String cad = new String();
        int num0=0;
        System.out.println("Introduce una cadena con ceros");
        t.nextLine();
        cad = t.nextLine();
        num0=contarCeros(cad);
        System.out.println("El número de los ceros dentro de la cadena es "+num0);
        
        // apartado e
        int numero1 = 0;
        int numero2 = 0;
        int rand = 0;
        System.out.println("introduce un número positivo");
        numero1 = t.nextInt();
        System.out.println("introduce un número mayor que el anterior");
        numero2 = t.nextInt();
        rand = aleatorio(numero1,numero2);
        System.out.println("Se genera el siguiente número aletorio "+rand);
    }
   

    // Función llamada par() que se le pasa un entero y devuelve true si es par, false si no lo es
  
   public static boolean par(int num){
        if(num%2==0) return true;
        return false;
    }
    // Función llamada mayor() que se le pasan 3 double y devuelve el mayor de ellos.
    
    public static double mayor(double x,double y,double z){
        if(x>=y && x>=z) return x;
        else if(y>=z) return y;
        else return z;
    }
    
    /*Función llamada sumaIntervalo() que le pasan dos long y devuelve otro long con la suma de los
    números comprendidos entre los números pasados (el primero es menor que el segundo, y ambos
    mayores que cero, en caso contrario devuelve -1)*/
    public static long sumaIntervalo(long a,long b){
        if(b>a && a>0 && b>0){
        int i=1;
        long suma=0;
        while (a+i<b){
            suma += a+i;
            i++;
        }
        return suma;
    }
        return -1;
    }

    
// Función llamada contarCeros() que se le pasa una cadena y devuelve la cantidad de ceros que tiene.
    public static int contarCeros(String a){
        int numero=0;
        int lon = a.length();
        for (int i = 0; i < lon; i++) {
            if(a.charAt(i)=='0') numero =numero+1;
        }
        return numero;
    }
    
/* Función llamada aleatorio() que se le pasan dos valores enteros devuelve un entero al azar
comprendido entre esos dos valores (el primero es menor que el segundo, y ambos mayores que cero,
en caso contrario devuelve -1)*/
    public static int aleatorio(int a,int b){
        if(b>a && a>0 && b>0){
            double randomNum = Math.random() * (b-a) +a;
            int n = (int) Math.round(randomNum);
            return n;
    }
        return -1;
    }
    
     
}
