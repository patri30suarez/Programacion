
package patricia.suarezdiazt05;

/*Este código es erróneo ¿Qué mostraría por pantalla? ¿Por qué?
public static void main(String[] args) {
 float saldo = 500f;
 saldo = ingresar(saldo, 400f);
 if (ingresar(saldo, 400f)>1000f)
 System.out.println("Ya tienes más de 1000 euros: " + saldo);
 else System.out.println("No tienes más de 1000 euros: " + saldo);
}
static float ingresar (float saldo, float increm){ return saldo+increm;} */
public class ej10 {
    // Con un saldo de 900 muestra que tenemos mas de 1000 porque en el if en vez de comprobar si el valor de saldo es mayor que 1000 llama a la funcion retirar sin darle valor a la variable
   
}
