
package patricia.suarezdiazt05;

import java.util.Scanner;
/* Hacer una función llamada CalcularDiasMes que se le pase como parámetro un año y un mes y
devuelva los días que tiene ese mes, teniendo en cuenta los años bisiestos. A continuación, realizar un programa al
que se le introduzca una fecha y nos informe de los días pasados desde el 1 de enero de ese año (no usar clases Java
de fechas). */
public class ej03 {
     public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        int año=0;
        int mes = 0;
        int dia = 0;
        int cont = 0;
        System.out.println("Introduce el año");
        año = t.nextInt();
        System.out.println("Introduce el mes");
        mes = t.nextInt();
        System.out.println("Introduce el dia");
        dia = t.nextInt();
        cont = dia-1;
        while(mes>1){
            mes--;
            cont += CalcularDiasMes(año,mes);
        }
        System.out.println("Los dias que han pasado desde el inicio de año son "+cont);
    }

    public static int CalcularDiasMes(int año, int mes) {
        int dias = 0;
        if ((año % 4 == 0 && año % 100 != 0 || año % 400 == 0) && mes == 2) {
            return dias = 29;
        }
        switch(mes){
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12: return dias=31;
            case 2: return dias = 28;
            case 4:
            case 6:
            case 9:
            case 11: return dias =30;
            default: return dias = 0;
        }
    }
}

