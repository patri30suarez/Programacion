
package patricia.suarezdiazt05;

import java.util.Scanner;

/*Partiendo de la función del programa anterior, hacer un programa al que se le introduzcan dos fechas
del mismo año y nos informe de los días comprendidos entre ellas (no usar clases Java de fechas)*/ 
public class ej04 {
     public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        int año=0, mes = 0, dia = 0, mes1 = 0, dia1 = 0,cont = 0,cont2=0,resta=0;
        System.out.println("Introduce el año");
        año = t.nextInt();
        System.out.println("Introduce el mes");
        mes = t.nextInt();
        System.out.println("Introduce el dia");
        dia = t.nextInt();
        cont = dia-1;
        while(mes>1){
            mes--;
            cont += CalcularDiasMes(año,mes);
        }
        System.out.println("Introduce otro mes del mismo año");
        mes1 = t.nextInt();
        System.out.println("Introduce otro dia");
        dia1 = t.nextInt();
        cont2 = dia1-1;
        while(mes1>1){
            mes1--;
            cont2 += CalcularDiasMes(año,mes1);
        }
     if(cont2>=cont){ resta = cont2 - cont;}
     if(cont>=cont2){ resta = cont - cont2;}
        System.out.println("los dias comprendidos son "+resta);
    }
   
    

    public static int CalcularDiasMes(int año, int mes) {
        int dias = 0;
        if ((año % 4 == 0 && año % 100 != 0 || año % 400 == 0) && mes == 2) {
            return dias = 29;
        }
        switch(mes){
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12: return dias=31;
            case 2: return dias = 28;
            case 4:
            case 6:
            case 9:
            case 11: return dias =30;
            default: return dias = 0;
        }
    }
}
