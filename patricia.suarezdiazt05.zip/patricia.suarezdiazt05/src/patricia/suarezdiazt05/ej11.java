/*
¿Qué mostraría este código por pantalla? ¿Por qué?
 public static void main(String[] args) {
 float saldo = 500f;
 ingresar(saldo, 600f);
 if (saldo > 1000f) System.out.println("Ya tienes más de 1000 euros: " + saldo);
 else System.out.println("No tienes más de 1000 euros: "+ saldo);
 }
 static void ingresar(float saldo, float increm) {saldo += increm; }*/
package patricia.suarezdiazt05;

public class ej11 {
    // muestra  No tienes más de 1000 euros: 500,
    // No se modifica el valor inicial a saldo
    
}
