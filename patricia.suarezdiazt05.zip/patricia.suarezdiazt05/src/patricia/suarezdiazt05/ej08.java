
package patricia.suarezdiazt05;

import java.util.Scanner;

/*Realizar un programa al que se le introduzcan dos números enteros positivos y nos diga cuál de los dos
tiene más divisores (usar función previa).*/
public class ej08 {
    
    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        int num;
        int num2;
        int div;
        int div2;
        System.out.println("Introduzca un número número: ");
        num = t.nextInt();
        System.out.println("Introduzca otro número: ");
        num2 = t.nextInt();
        div = cantidadDivisores(num);
        div2 = cantidadDivisores(num2);
        
        if (div > div2) {
            System.out.println("El número con más divisores es: "+num);            
        }else if (div2 > div){
            System.out.println("El número con más divisores es: "+num2);
        }else{
            System.out.println("Tienen la misma cantidad de divisores.");
        }
    }
 public static int cantidadDivisores(int num) {
        int cont = 0;
        if (num <= 0) {
            return 0;
        }
        for (int i = num; i >= 1; i--) {
            if (num % i == 0) {
                cont++;                
            }
        }
        return cont;
    }

}

