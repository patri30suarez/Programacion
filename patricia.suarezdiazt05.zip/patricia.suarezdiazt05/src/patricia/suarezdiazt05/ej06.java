
package patricia.suarezdiazt05;

import java.util.Scanner;

/* Realiza una función llamada cantidadDivisores al que se le pase como parámetro un número entero y
devuelva el número de divisores o bien cero si el número es negativo. Usa dicha función en un main.
*/
public class ej06 {
    
 public static void main(String[] args) {
    int num = 0;
    int div = 0;
    Scanner t = new Scanner(System.in);
    System.out.println("Introduce un número entero");
    num = t.nextInt();
    div = calcularDivisores(num);
    System.out.println("Si el numero es positivo el número de divisores es "+div);
    }
    public static int calcularDivisores(int num){
        int cont = 0;
        int decre = num;
        if(num<=0) return 0;
        while (decre>0){
            if(num%decre==0) cont++;
            decre--;
        }
        return cont;
    }
}

