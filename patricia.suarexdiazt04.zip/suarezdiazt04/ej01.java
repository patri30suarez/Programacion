/*
 Por defecto usar clase String. Se especificará cuando se deba usar la clase StringBuilder.
Realizar un programa al que se le introduzca una cadena por teclado y haga lo siguiente
 */
package patricia.suarezdiazt04;

import java.util.Scanner;

public class ej01 {

    public static void main(String[] args) {
//  Mostrar por pantalla el contenido de la cadena pasada a mayúsculas y minúsculas
        Scanner t = new Scanner(System.in);

        System.out.println("Introduce una cadena ");
        String cad = new String();
        cad = t.nextLine();
        String may = cad.toUpperCase();
        String min = cad.toLowerCase();
        System.out.println(may);
        System.out.println(min);
// Decir si en la cadena aparece el carácter ‘x’          
        int pos = cad.indexOf('x');
        if (pos != -1) {
            System.out.println("tiene una x en la posicion " + pos);
        }

//Decir si la cadena tiene más de 10 posiciones
        int lon = cad.length();
        if (lon > 10) {
            System.out.println("Tiene mas de 10 posiciones");
        }

//Decir si la cadena contiene el carácter ‘x’ a partir de la cuarta posición
        int pos2 = cad.indexOf("x", 3);
        if (pos != -1) {
            System.out.println("tine una x a partir de la posicion 4 en la posición" + pos2);
        }

//Crear una cadena formada por las 5 primeras posiciones de la cadena.
        if (lon > 5) {
            String sub1 = cad.substring(0, 5);
            System.out.println(sub1);
        };

//Crear una cadena formada por las 5 últimas posiciones de la cadena.
        if (lon > 5) {
            String sub2 = cad.substring(lon - 5);
            System.out.println(sub2);
        };

//Decir si la cadena es igual a la cadena “hola”.
        String cad2 = new String("hola");
        if (cad.equals(cad2)) {
            System.out.println("Cadena igual a hola ");
        }
        else System.out.println("cadena distinta a hola");

//Convertir la cadena a un número entero (puede ser negativo o positivo)
        int numero = Integer.parseInt(cad);
        System.out.println("En numero decimal es " + numero);

//Convertir la cadena a un número hexadecimal
        int numh = Integer.parseInt(cad, 16);
        System.out.println("En numero hexadecimal es " + numh);

//Si se encuentra con en su interior con “prueva” sustituir por “prueba”
        String cadr = cad.replace("prueva", "prueba");
        System.out.println(cadr);

//Decir si la primera posición de la cadena es igual a la última. 
        if (cad.charAt(0)==cad.charAt(lon-1)) {
            System.out.println("La primera posición de la cadena es igual a la última ");
        }
        else System.out.println("La primera posición de la cadena es distinta a la última  ");

//Decir cuántos dígitos numéricos hay en la cadena
        int contador = 0;
        for (int i = 1; i < lon; i++) {
            char letra = cad.charAt(i);
            if (Character.isDigit(letra)) {
                contador++;
            }
        }
        System.out.println("Hay " + contador + " digitos en la cadena");
//Decir si la cadena es un palíndromo (se lee igual hacia adelante como hacia atrás)
        boolean palidromo = true;
        for (int i = 0; i < (lon/2)+1; i++) {
            if (cad.charAt(lon - i) != cad.charAt(i)) {
                palidromo = false;
                break;
            }
        }
        if (palidromo) {
            System.out.println("Es un palíndromo");
        } else 
            System.out.println("No es un palíndromo");

//Crear una cadena que sea igual a la introducida, pero con la primera y última posiciones intercambiadas;
        String med = cad.substring(1, lon);
        String prim = cad.substring(0, 1);
        String ult = cad.substring(lon);
        String res = ult.concat(med).concat(prim);
        System.out.println(res);
    }
}
