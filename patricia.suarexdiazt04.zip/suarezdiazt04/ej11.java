/*
Describe que realiza el código siguiente e indica si contiene algún error.
 java.util.Scanner teclado = new java.util.Scanner(System.in);
 System.out.println("Introduce una cadena:");
 String cadena = teclado.nextLine();
 StringBuilder cadenaSB = new StringBuilder(cadena);
 int pos;
 do {
 pos = cadenaSB.indexOf(" ");
 if (pos!=-1) cadenaSB.deleteCharAt(pos);
 } while (pos != -1);
 System.out.println(cadenaSB); 
 */
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;

public class ej11 {

  public static void main(String[] args) {
      java.util.Scanner teclado = new java.util.Scanner(System.in);
 System.out.println("Introduce una cadena:");
 String cadena = teclado.nextLine();
 StringBuilder cadenaSB = new StringBuilder(cadena);
 int pos;
 do {
 pos = cadenaSB.indexOf(" ");
 if (pos!=-1) cadenaSB.deleteCharAt(pos);
 } while (pos != -1);
 System.out.println(cadenaSB); 
 /*
Primero se convierte la cadena a un StringBuilder.
Despues hacer un bucle donde pos coge los valores de lso espacios de cadenaSB.
Si el valor de pos es distinto a -1 borra los espacios hasta que pos valga -1.
*/
    }
}
