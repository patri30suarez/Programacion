/*
Realizar un programa que solicite la entrada de 10 cadenas de caracteres y construya una cadena con el
primer carácter de cada cadena. Finalmente mostrará dicha cadena por pantalla.
 */
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;

public class ej10 {

  public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        String cad = new String();
        String fin = new String();
        
        for (int i = 0; i < 10; i++) {
            System.out.println("Introduce una cadena");
            cad = t.nextLine();
            fin += cad.charAt(0);
        }
        System.out.printf("los caracteres introducidos son: "+fin);
    }
}
