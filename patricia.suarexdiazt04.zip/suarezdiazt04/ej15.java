/*
Realizar un programa en el que el usuario introduzca un texto y sustituya 
sus posiciones impares por asteriscos, por ejemplo: “abcdefg” cambie 
las posiciones impares pasaría a: “a*c*e*g”

 */
package patricia.suarezdiazt04;

import java.util.Scanner;

public class ej15 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        String cadena = new String();
        
        System.out.println("Introduzca una cadena: ");
        cadena = t.nextLine();
        
        for (int i = 0; i < cadena.length(); i++) {
            if (i % 2 != 0) {
                cadena = cadena.substring(0, i) +"x"+cadena.substring(i+1);
            }
        }
        System.out.println("Cadena después de los cambios: "+cadena);
    }

}
