/*
Realiza un programa al que se le introduzca un email y nos devuelva el nombre del dominio y
subdominios si los hubiese, es decir, lo que está entre la arroba y el punto final (Ejemplo:
info@empresas.clientes.mundo-r.com mostraría empresas.clientes.mundo-r ). 
 */
package patricia.suarezdiazt04;
import java.util.Random;
import java.util.Scanner;

public class ej06 {

    public static void main(String[] args) {
        Scanner t = new Scanner (System.in);
        String email= new String();
        int pos, pos2;
       System.out.println("Introduce tu email");
       email= t.nextLine();
       pos=email.indexOf ("@")+1;
       pos2=email.indexOf ("."); 
       String sub = email.substring(pos, pos2);
        System.out.println(sub);
        
            
    }

}
    
