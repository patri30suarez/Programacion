/*
Realizar un programa que solicite una cadena, un número que indica una posición de la cadena y una
letra. El programa reemplazará sobre la misma cadena, el carácter que hubiera en la posición indicada por la letra
introducida. Hacer dos versiones, la primera con String y otra con StringBuilder.
 */
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;

public class ej08 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        String cadena = new String();
        String letra = new String();
        int pos;
        
      System.out.println("Introduce tu cadena");
        cadena = t.nextLine();
        System.out.println("Introduce la letra");
        letra = t.nextLine();
        System.out.println("Introduce la posicion");
        pos = t.nextInt();
        String sub = cadena.substring(0,pos-1);
        String sub2 = cadena.substring(pos);
        String frase=sub+letra+sub2;
        System.out.println(frase);
        
// version 2
StringBuilder cad2;
char letra2;
int pos2;
System.out.println("Introduzca una frase");
        cad2 = new StringBuilder(t.nextLine());
System.out.println("Introduzca una letra");
        letra2 = t.nextLine().charAt(0);
System.out.println("Introduzca una posición");
        pos2 = t.nextInt();
cad2.setCharAt(pos2-1, letra2);
        System.out.println(cad2);
    }
}
