/*
Realizar un programa que solicite la entrada de una cadena de 6 posiciones, que todas sean dígitos y sin
repetidos. Si no cumple esas condiciones, el usuario deberá introducirla de nuevo hasta que lo haga correctamente. 
 */
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;

public class ej12 {

  public static void main(String[] args) {
      Scanner t = new Scanner(System.in);
       String cad = new String();
        boolean cond = true;
        do {
            System.out.println("Introduce una cadena de 6 digitos sin repetirlos");
            cad = t.nextLine();
            if (cad.length() == 6) {
                for (int i = 0; i < cad.length(); i++) {
                    if (Character.isDigit(cad.charAt(i))) {
                        for (int j = i + 1; j < cad.length(); j++) {
                            if (cad.charAt(i) != cad.charAt(j)) {
                                cond = false;
                            }
                            else {
                                System.out.println("Hay digitos repetidos");
                                cond = false;
                                break;}
                        }
                    }
                        else {
                        System.out.println("Se tiene que introducir digitos");
                        cond = true;
                        break;}
                    }
                      }
            else
                System.out.println("El número de digitos es incorrecto.");
        }
        while (cond);
        System.out.println("La cadena es correcta.");   
    }

}
