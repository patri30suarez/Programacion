/*
 Diseña un algoritmo capaz de obtener la letra del nif a partir del número de dni. Consiste en dividir
dicho número entre 23 y tomar el resto de la división asignándole la letra correspondiente según la siguiente tabla.
Almacena las letras del NIF en una cadena.
RESTO 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22
LETRA T R W A G M Y F P D X B N J Z S Q V H L C K E
*/
package patricia.suarezdiazt04;

import java.util.Scanner;
public class ej02 {

    public static void main(String[] args) {
Scanner t = new Scanner (System.in);
int resto,dni;
System.out.println("Introduce tu numero del DNI");
dni= t.nextInt();
String valores="TRWAGMYFPDXBNJZSQVHLCKE";
resto= dni % 23;
char letra = valores.charAt(resto);
        System.out.println("Tu dni completo es "+dni+letra);
    }
    
}
