/*
Escribe un programa que solicite que se introduzca por teclado un nombre completo y una edad y
muestre el siguiente mensaje, utilizando la clase Format.
Hola, me llamo Pepe Pérez López y tengo 20 años
 */
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;

public class ej09 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        String nombre = new String();
        int edad;
        
      System.out.println("Introduce tu nombre");
        nombre = t.nextLine();
        System.out.println("Introduce tu edad");
        edad = t.nextInt();
        System.out.printf("Hola, me llamo %s y tengo %d años", nombre, edad);
    }
}
