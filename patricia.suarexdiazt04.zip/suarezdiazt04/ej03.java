/*
Realiza un programa que solicite que se le introduzcan una cadena y un carácter y nos muestre cuantas
veces está contenido el carácter en la cadena.
*/
package patricia.suarezdiazt04;

import java.util.Scanner;
public class ej03 {

    public static void main(String[] args) {
Scanner t = new Scanner (System.in);
String cad = new String();
System.out.println("Introduce una cadena");
cad= t.nextLine();
String car= new String();
        System.out.println("Introduce un caracter");
 car=t.nextLine();
 int cont=0,pos;
  pos = cad.indexOf(car);
        while (pos != -1) { 
            cont++;                                  
            pos = cad.indexOf(car, pos + 1);
            
        }
        System.out.println("el caracter "+car+" esta contenido "+cont+" veces");
    }
    
}