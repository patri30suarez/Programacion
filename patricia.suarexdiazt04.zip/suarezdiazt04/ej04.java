/*
Realiza un programa que muestre una contraseña generada aleatoriamente teniendo las siguientes
limitaciones: Tendrá entre 5 y 10 posiciones que solo pueden ser letras entre la ‘a’ y la ‘j’.
*/
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;
public class ej04 {

    public static void main(String[] args) {
Scanner t = new Scanner (System.in);
String valores = "abcdefghij";
int pos = 0;
String cont = new String();
int tamaño =(int) (Math.random()*5)+5;
        for (int i = 0; i < tamaño; i++) {
            pos=(int)(Math.random()*10);
            cont += valores.charAt(pos);
        }
        System.out.println("la contraseña es "+cont);

    }
    
}