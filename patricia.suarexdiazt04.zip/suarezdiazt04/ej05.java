/*
Realiza un programa que muestre una contraseña generada aleatoriamente teniendo las siguientes
limitaciones: Tendrá entre 5 y 10 posiciones que solo pueden ser letras entre la ‘a’ y la ‘j’ pero sin letras repetidas.
 */
package patricia.suarezdiazt04;
import java.util.Random;
import java.util.Scanner;

public class ej05 {

    public static void main(String[] args) {
        String valores = "abcdefghij";
        Random ra= new Random();
        int tamaño =(int) (Math.random()*5)+5;
        String pass = new String();
        while (pass.length() != tamaño) {
            int num = ra.nextInt(9);
            char letra = valores.charAt(num);
            int pos = pass.indexOf(letra);
            if (pos < 0) {
                pass = pass + letra;
            }
        }
        System.out.println("la contraseña es " + pass);
    }

}
    
