/*
Realizar un programa al que se le introduzca una cadena por teclado, que la convierta a StringBuilder,
y aplicando métodos de esa clase, haga lo siguiente:
a. Borrar el carácter que haya en la posición 3.
b. Insertar una ‘x’ en la posición 5.
c. Sustituir el carácter de la posición 1 por una ‘z’.
d. Borrar los caracteres entre la posición 5 y 10.
e. Darles la vuelta a todos los caracteres del StringBuilder.
f. Convertir el StringBuilder en cadena.
Habrá que verificar en algunos casos que la cadena tiene una longitud mayor que la de
la posición indicada, sino producirá errores.
 */
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;

public class ej14 {

  public static void main(String[] args) {
      Scanner t = new Scanner(System.in);
       String cad = new String();
        boolean cond = true;
do {
            System.out.println("Introduce una frase");
            cad = t.nextLine();
            if (cad.length() >= 10) {
                StringBuilder sb = new StringBuilder(cad);
                //Borrar el carácter que haya en la posición 3
                sb.delete(3, 4);
                //Insertar una ‘x’ en la posición 5.
                sb.insert(5, "x");
                //Sustituir el carácter de la posición 1 por una ‘z’.
                sb.replace(1, 2, "z");
                //Borrar los caracteres entre la posición 5 y 10.
                sb.delete(6, 10);
                //Darles la vuelta a todos los caracteres del StringBuilder.
                sb.reverse();
                //Convertir el StringBuilder en cadena.
                cad = sb.toString();
                System.out.println(cad);
                cond= false;
            } else {
                System.out.println("La cedena tiene que ser más larga");
                cond = true;
            }
        } while (cond);
    }

}
