/*
Un algoritmo de encriptado monoalfabético consiste en la sustitución de una letra por otra a lo largo de
todo el mensaje, por ejemplo las A por F, las B por X, las C por M. Obviamente si la A pasa a ser F, ninguna otra
letra pasará F. Hacer un programa que le introduzca una cadena en mayúsculas y muestre la cadena encriptada en
(todo lo que no sean letras mayúsculas se deja intacto: números, espacios en blanco, etc.). Hacer una segunda
versión que funcione con mayúsculas y minúsculas
 */
package patricia.suarezdiazt04;

import java.util.Random;
import java.util.Scanner;

public class ej07 {

    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        String mensaje = new String();
        String cifrado = new String();
        System.out.println("Introduce tu mensaje");
        mensaje = t.nextLine();
        cifrado=mensaje.replace('A', 'F').replace('B', 'X').replace('C', 'M');
        System.out.println("el mensaj eifrado es "+cifrado);
        
    // Version 2
 System.out.println("Introduce tu mensaje");
        mensaje = t.nextLine();
        mensaje= mensaje.toUpperCase();
        cifrado=mensaje.replace('A', 'F').replace('B', 'X').replace('C', 'M');
        System.out.println("el mensaj eifrado es "+cifrado);
    }
}
