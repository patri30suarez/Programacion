package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej09 {

    public static void main(String[] args) {
        /*Realizar un programa al que se le introduzca la hora del día (0 –23) y nos diga que
días de la semana hay salida de bus (utilizar la tabla anterior).
         Lunes Martes Mierc. Jueves Viernes Sábado Domingo
9:00                                                 Si 
10:00     Si    Si    Si      Si     Si      Si      Si
11:00                                                Si
12:00                         Si                     Si
13:00                                                Si
14:00     Si    Si    Si      Si     Si              Si   */
        Scanner t = new Scanner(System.in);
        String dia;
        int hora;
        System.out.print("Dime la hora ");
        hora = t.nextInt();
        switch (hora) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:  dia="no hay"; break;
            case 9:  dia = "domingo"; break;
            case 10: dia = "lunes, martes, miercoles, jueves, viernes, sabado y domingo"; break;
            case 11: dia = "domingo"; break;
            case 12: dia = "jueves y domingo"; break;
            case 13: dia = "domingo"; break;
            case 14: dia = "lunes, martes, miercoles, jueves, viernes y doming"; break;
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23: dia="no hay"; break;
            default: dia = "Ese número no corresponde a ninguna hora";
    }
            System.out.println("hay bus a esa hora los: " +dia);
        
    }
}
