

package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01k {

    public static void main(String[] args) {
        /*Leer un número y decir si es múltiplo de 2, de 3 y/o de 10. Si no es múltiplo de
2 ya no hay que mirar si lo es de 10.*/
         Scanner t = new Scanner (System.in);
         int num;
         System.out.println("Dime un numero "); 
         num=t.nextInt();
        if ((num%2==0 && num%3==0) || (num%2==0 &&num%10==0))
            System.out.println("El numero es multiplo de 2 y de 3 o de 10");
        else 
          System.out.println("El numero  no es multiplo de 2 o de 3 o de 10");    
    }
    
}
