package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej05 {

    public static void main(String[] args) {
        /* Diseñar un algoritmo al que se le introduzca la cantidad de horas, minutos y segundo
mostrados en un reloj digital, que verifique que los valores sean correctos y calcule el total
de segundos transcurridos desde el comienzo del día. No emplear las clases de fecha de
Java.*/
        Scanner t = new Scanner(System.in);
        int hora, minutos, segundos;
        System.out.println("Dime la hora ");
        hora = t.nextInt();
        System.out.println("Dime los minutos ");
        minutos = t.nextInt();
        System.out.println("Dime los segundos ");
        segundos= t.nextInt();
        
        if (hora>23 || minutos>59 || segundos>59 || hora<0 || minutos<0 || segundos<0 )
            System.out.println("Escribiste mal la hora");
        else if (hora==0){
            segundos=segundos*minutos;
            System.out.println("Han trascurido "+segundos);}
        else if (minutos==0){
            segundos=segundos*hora;
            System.out.println("Han trascurido "+segundos);}
         else if (segundos==0){
            segundos=minutos*hora;
            System.out.println("Han trascurido "+segundos);}
        else{
            segundos=segundos*minutos*hora;
            System.out.println("Han trascurido "+segundos);}
        
    }
}
