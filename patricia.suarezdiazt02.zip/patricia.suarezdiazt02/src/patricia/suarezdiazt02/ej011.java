package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej011 {

    public static void main(String[] args) {
        /* Realizar un programa al que se le introduzcan DIA, MES, AÑO, que calcule el día
        siguiente. Suponemos que los valores son correctos, sin emplear las clases de fechas de
        Java.
        Hay que hacer un tratamiento diferente según sea fin de año, fin
        de mes (no fin de año) o un día no fin de mes.*/
        Scanner t = new Scanner(System.in);
        int dia, mes, año;
        System.out.print("Dime el dia ");
        dia = t.nextInt();
        System.out.println("Dime el mes ");
        mes = t.nextInt();
        System.out.println("Dime el año ");
        año = t.nextInt();
        dia++;
        if (dia==32 && mes==12){
            año++;
            dia=1;
            mes=1;
            System.out.println("Mañana será: " +dia+"-"+mes+"-"+año); }
        else if (dia==32){
            mes++;
            dia=1;
            System.out.println("Mañana será: " +dia+"-"+mes+"-"+año); }
        else if ((mes==4 || mes==6 || mes==9 || mes==11) && dia==31) {
            mes++;
            dia=1;
            System.out.println("Mañana será: " +dia+"-"+mes+"-"+año);} 
        else if (mes ==2 && dia==30){
            mes++;
            dia=1;
            System.out.println("Mañana será: " +dia+"-"+mes+"-"+año); }
        else if (mes ==2 && dia==29 &&(año%4==0 && año%100!=0 ||año%400==0))
             System.out.println("Mañana será: " +dia+"-"+mes+"-"+año);
        else if (mes ==2 && dia==29){
            mes++;
            dia=1;
            System.out.println("Mañana será: " +dia+"-"+mes+"-"+año); }
        else 
             System.out.println("Mañana será: " +dia+"-"+mes+"-"+año); 
    }
}
