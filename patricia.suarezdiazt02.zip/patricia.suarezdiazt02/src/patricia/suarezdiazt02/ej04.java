package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej04 {

    public static void main(String[] args) {
        /* Para aprobar el curso se valorará la nota del examen, la valoración del trabajo en
clase y la nota de un trabajo práctico. Aprobarán los alumnos que estén en alguna de las
siguientes situaciones:
 Nota examen mayor o igual a 5
 Nota examen entre 4 y 5, trabajo en clase mayor que cinco y trab. práctico mayor
que 5.
 Nota examen entre 4 y 5, y una nota mayor que 8 o en el trabajo práctico o en la
valoración del trabajo en clase.
Diseñar un algoritmo que lea la nota del examen, la valoración del trabajo en clase y la
nota del trabajo práctico y saque por pantalla si está aprobado o no, todo en con una
sola sentencia condicional.*/
        Scanner t = new Scanner(System.in);
        Float exam, trabc, trabp;
        System.out.println("Dime la nota del examen ");
        exam = t.nextFloat();
        System.out.println("Dime la valoracion del trabajo en clase ");
        trabc = t.nextFloat();
        System.out.println("Dime la nota del trabajo practico ");
        trabp= t.nextFloat();
        
        if (exam>=5||(exam<=5 && exam>=4 && trabc>5 && trabp>5) || (exam<=5 && exam>=4 &&(trabc>8 || trabp>8)))
            System.out.println("Estas aprobado");
        else 
            System.out.println("Estas suspenso");
        
    }
}
