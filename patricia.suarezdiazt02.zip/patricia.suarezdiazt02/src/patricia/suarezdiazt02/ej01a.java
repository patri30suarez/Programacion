
package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01a {

    public static void main(String[] args) {
        // Leer un número entero y determinar si es mayor de 10
         Scanner t = new Scanner (System.in);
         int num;
         System.out.println("Dime un numero ");
         num=t.nextInt();
         if (num > 10)
             System.out.println("Es mayor que 10 ");
         else 
             System.out.println("Es menor que 10");
         
    }
    
}
