package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej013 {

    public static void main(String[] args) {
        /* IRealizar un programa que se le introduzca una nota (un valor entero entre 0 y 10) y
nos muestre por pantalla la nota final en texto, con la siguiente equivalencia: Muy
deficiente (0,1,2), Insuficiente (3,4), Aprobado (5,6), Notable (7,8) y Sobresaliente (9,10). */
          Scanner t = new Scanner(System.in);
        String texto;
        int nota;
        System.out.print("Dime tu nota ");
        nota = t.nextInt();
        switch (nota) {
            case 0:
            case 1:
            case 2: texto="muy deficiente"; break;
            case 3:
            case 4: texto="insuficiente";break;
            case 5:
            case 6: texto="aprobado";break;
            case 7:
            case 8:  texto="notable"; break;
            case 9:
            case 10: texto = "sobresaliente"; break;
            default: texto = "Ese número no corresponde a ninguna nota";
    }
            System.out.println("tu nota es " +texto);
        
    }
}      