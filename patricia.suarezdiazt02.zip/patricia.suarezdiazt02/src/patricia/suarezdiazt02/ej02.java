

package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej02 {

    public static void main(String[] args) {
        /* Haz 3 versiones de un mismo programa, que pida que se introduzcan por teclado 2
números double sobre sendas variables llamadas ‘a’ y ‘b’ y que incluyan las instrucciones
que se muestran abajo. Para cada una de las versiones, ejecútalo varias veces,
introduciendo cero para alguno de los valores y finalmente explica la diferencia de
comportamiento entre cada una de las versiones:*/
         Scanner t = new Scanner (System.in);
         double a, b,r;
         System.out.println("Dime un numero "); 
         a=t.nextDouble();
         System.out.println("Dime otro numero "); 
         b=t.nextDouble();
       /* if (b !=0 && a/b==0) {
            r = a/b; 
        System.out.println(r);}  */
       /*comprueba primero si el valor de b es distinto de cero y si lo es hace la division de a entre b y comprueba que valga cero
       si lo anterior se cumple guarda el resultado de la division en la variable r 
       devuelve el valor de r */
       /* if (a/b==0 && b !=0) {
            r = a/b; 
            System.out.println(r);}
        */
        /* primero hace la division de a entre b y comprueba que valga cero  y si es asi comprueba que el valor de b es distinto de cero
       si lo anterior se cumple guarda el resultado de la division en la variable r 
       devuelve el valor de r */
          if (b !=0 & a/b==0) {
             r = a/b; 
             System.out.println(r);}
        /* se evalúan si b es distinto de cero y hace la division de a entre b y comprueba que valga cero aunque la primera condicion no se cumpla
        si lo anterior se cumple guarda el resultado de la division en la variable r 
       devuelve el valor de r */
       
    }
    
}
