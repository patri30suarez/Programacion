

package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01m {

    public static void main(String[] args) {
        //Leer tres números enteros y diga hay alguno mayor que cero, pero no todos.
         Scanner t = new Scanner (System.in);
         int num1, num2, num3;
         System.out.println("Dime un numero "); 
         num1=t.nextInt();
         System.out.println("Dime otro numero "); 
         num2=t.nextInt();
         System.out.println("Dime otro numero "); 
         num3=t.nextInt();
        if ((num1>0 || num2>0 || num3>0) && (num1<0 || num2<0 || num3<0) )
            System.out.println("Uno o dos de los tres numeros es mayor de cero");
        else 
          System.out.println("Ninguno de los tres numeros es mayor de cero o varios de ellos son mayores de cero");   
    }
    
}
