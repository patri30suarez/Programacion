

package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01h {

    public static void main(String[] args) {
        /*Leer dos números y decir si el primero es mayor que el segundo, si es menor o si
los dos números son iguales*/
         Scanner t = new Scanner (System.in);
         int num1, num2;
         System.out.println("Dime un numero "); 
         num1=t.nextInt();
         System.out.println("Dime otro numero "); 
         num2=t.nextInt();
         if (num1<num2)
             System.out.println("el primer numero es el menor ");
         else if (num1>num2)
             System.out.println("el primer numero es el mayor ");
         else
             System.out.println("son iguales ");
    }
    
}
