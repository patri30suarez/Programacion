package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej012 {

    public static void main(String[] args) {
        /* Introduciendo dos fechas (día, mes, año), hacer un programa que nos diga cuál de
las dos es mayor (agrupa las condiciones de día, mes y año en una sola sentencia
condicional). Suponemos que se introducen fechas válidas y no empleamos las clases de
fecha de Java.*/
        Scanner t = new Scanner(System.in);
        int dia1, mes1, año1, dia2, mes2, año2;
        System.out.print("Dime un dia ");
        dia1 = t.nextInt();
        System.out.println("Dime un mes ");
        mes1 = t.nextInt();
        System.out.println("Dime un año ");
        año1 = t.nextInt();
        System.out.print("Dime otro dia ");
        dia2 = t.nextInt();
        System.out.println("Dime otro mes ");
        mes2 = t.nextInt();
        System.out.println("Dime otro año ");
        año2 = t.nextInt();
        
        if ( (año1>año2)||(año1==año2 && mes1>mes2)|| (año1==año2 && mes1==mes2 && dia1>dia2 ) )
            System.out.println("Es mayor la primera fecha");
        else 
            System.out.println("Es mayor la segunda fecha");
    }
}
