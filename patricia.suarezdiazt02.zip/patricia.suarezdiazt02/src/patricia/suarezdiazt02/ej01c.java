
package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01c {

    public static void main(String[] args) {
        // Leer un número entero y de determinar si se trata de un número par o impar
         Scanner t = new Scanner (System.in);
         int num;
         System.out.println("Dime un numero ");
         num=t.nextInt();
         if (num% 2 == 0)
             System.out.println("Es par ");
         else 
             System.out.println("Es impar ");
         
    }
    
}
