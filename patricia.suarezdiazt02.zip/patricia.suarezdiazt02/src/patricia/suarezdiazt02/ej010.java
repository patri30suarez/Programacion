package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej010 {

    public static void main(String[] args) {
        /*Realizar un programa al que se le introduzcan DIA, MES, AÑO, que verifique que los
valores introducidos sean correctos, sin emplear las clases de fechas de Java.
Si primero calculamos los días que tiene un mes/año, luego será
muy fácil la verificación de la fecha.  */
        Scanner t = new Scanner(System.in);
        int dia, mes, año;
        System.out.print("Dime el dia ");
        dia = t.nextInt();
        System.out.println("Dime el mes ");
        mes = t.nextInt();
        System.out.println("Dime el año ");
        año = t.nextInt();
        if ((mes==1 || mes==3 || mes==5 || mes==7 || mes==8 || mes==10 || mes==12) && dia==31)
            System.out.println("Los datos estan correctos");
        else if ((mes==4 || mes==6 || mes==9 || mes==11) && dia==30)
            System.out.println("Los datos estan correctos");
        else if (año%4==0 && (año%100!=0 ||año%400==0) && mes==2 && dia==29)
            System.out.println("Los datos estan correctos");
        else if (mes ==2 && dia==28)
            System.out.println("Los datos estan correctos");
        else
            System.out.println("Los datos estan incorrectos");
    }
}
