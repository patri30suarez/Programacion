
package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01e {

    public static void main(String[] args) {
        // Leer dos números enteros y diga si al menos uno de los dos es mayor de 10.
         Scanner t = new Scanner (System.in);
         int num1, num2;
         System.out.println("Dime un numero ");
         num1=t.nextInt();
         System.out.println("Dime otro numero ");
         num2=t.nextInt();
         if (num1 > 10 || num2 > 10)
             System.out.println("Es mayor que 10");
         else 
             System.out.println("Es menor que 10");
         
    }
    
}
