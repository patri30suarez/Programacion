package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej07 {

    public static void main(String[] args) {
        /*Realizar un programa que informe si un año introducido previamente es bisiesto o
no. Son bisiestos los años múltiplos de 4 que no sean múltiplos de 100. Como excepción los
múltiplos de 400 también son bisiestos. Se puede hacer una primera versión con varias
sentencias condicionales y otra más sofisticada con una sola. No usar las clases de fechas
de Java.*/
        Scanner t = new Scanner(System.in);
        int año;
        System.out.print("Dime el año ");
        año = t.nextInt();
        if ((año%4==0 && año%100!=0) || (año%4==0 && año%400==0)){
            System.out.println("El año: "+año+"es bisiesto" );
        }
        else{
            System.out.println("El año: "+año+" no es bisiesto");
        }
        
    }
}
