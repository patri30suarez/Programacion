

package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01i {

    public static void main(String[] args) {
        /*Leer dos números enteros y diga si el segundo es divisor del primero (prevenir
divisiones por cero, que causan error) Repasar operadores en cortocircuito para
hacer un solo if*/
         Scanner t = new Scanner (System.in);
         int den, num;
         System.out.println("Dime un numero "); 
         num=t.nextInt();
         System.out.println("Dime otro numero"); 
         den=t.nextInt();
        if (den != 0 && num%den == 0)
          System.out.println("El segundo numero es divisor del primero");
        else 
          System.out.println("El segundo numero no es divisor del primero o no se puede hacer la division");   
    }
    
}
