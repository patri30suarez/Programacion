
package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01d {

    public static void main(String[] args) {
        // Leer dos números enteros y diga si los dos son mayores de 10 o no lo son.
         Scanner t = new Scanner (System.in);
         int num1, num2;
         System.out.println("Dime un numero ");
         num1=t.nextInt();
         System.out.println("Dime otro numero ");
         num2=t.nextInt();
         if (num1 > 10 && num2 > 10)
             System.out.println("Son mayores que 10");
         else 
             System.out.println("Son menores que 10");
         
    }
    
}
