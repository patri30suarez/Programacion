
package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01b {

    public static void main(String[] args) {
        // Leer dos números enteros y muestre si el primero es mayor que el segundo.
         Scanner t = new Scanner (System.in);
         int num1, num2;
         System.out.println("Dime un numero ");
         num1=t.nextInt();
         System.out.println("Dime otro numero ");
         num2=t.nextInt();
         if (num1 > num2)
             System.out.println("Es mayor el primero");
         else if (num1 < num2) 
             System.out.println("Es menor el primero");
         else 
              System.out.println("Son iguales ");
         
    }
    
}
