

package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01l {

    public static void main(String[] args) {
        //Leer tres números enteros y diga hay alguno mayor que cero.
         Scanner t = new Scanner (System.in);
         int num1, num2, num3;
         System.out.println("Dime un numero "); 
         num1=t.nextInt();
         System.out.println("Dime otro numero "); 
         num2=t.nextInt();
         System.out.println("Dime otro numero "); 
         num3=t.nextInt();
        if (num1>0 || num2>0 ||num3>0 )
            System.out.println("Uno de los tres numeros es mayor de cero");
        else 
          System.out.println("ninguno de los tres numeros es mayor de cero");    
    }
    
}
