
package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01f {

    public static void main(String[] args) {
        /* Leer un número entero y decir si está comprendido entre 10 y 20 (ambos
incluidos).*/
         Scanner t = new Scanner (System.in);
         int num;
         System.out.println("Dime un numero ");
         num=t.nextInt();
         if (num>= 10 && num<=20)
             System.out.println("Esta comprendido entre 10 y 20 ");
         else 
             System.out.println("No esta comprendido entre 10 y 20  ");
         
    }
    
}
