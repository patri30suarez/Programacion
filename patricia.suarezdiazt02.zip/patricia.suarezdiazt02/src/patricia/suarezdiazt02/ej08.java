package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej08 {

    public static void main(String[] args) {
        /*La tabla siguiente representa las horas de salida de un bus. Diseña un algoritmo al
que se le introduzca el día (1-7) y la hora (9-14), verifique la entrada y nos informe si hay
bus o no. Hacer una primera condición que haga la verificación de la entrada de datos y
otra única condición para ver si hay bus.
        Lunes Martes Mierc. Jueves Viernes Sábado Domingo
9:00                                                 Si 
10:00     Si    Si    Si      Si     Si      Si      Si
11:00                                                Si
12:00                         Si                     Si
13:00                                                Si
14:00     Si    Si    Si      Si     Si              Si
Hay que tratar de hacer un “if” que agrupe todas las condiciones.
Piensa como lo dirías si alguien te preguntase a qué horas hay bus
y luego trata de pasarlo a una sola condición en Java.*/
        Scanner t = new Scanner(System.in);
        int hora, dia;
        System.out.print("Dime el dia (1-7) ");
        dia = t.nextInt();
        System.out.print("Dime la hora (9-14)");
        hora = t.nextInt();
        if (dia>7||(hora<9&&hora>14))
            System.out.println("Estan mal los datos");
        else if (hora==10 || dia==7 || (dia!=6 && hora==14) || (dia==4 && hora==12)){
            System.out.println("Hay bus" );
        }
        else  {
            System.out.println("No hay bus");
        }
        
    }
}
