
package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej01g {

    public static void main(String[] args) {
        //Leer dos números enteros y diga si uno y solo uno es mayor de 10
         Scanner t = new Scanner (System.in);
         int num1, num2;
         System.out.println("Dime un numero "); 
         num1=t.nextInt();
         System.out.println("Dime otro numero "); 
         num2=t.nextInt();
         if (num1> 10 && num2>10)
             System.out.println("Son mayores que 10");
         else if ((num1> 10 && num2<10)||(num1<10 && num2>10))
             System.out.println("Uno es mayor que 10");
         else 
             System.out.println("los dos son menores que 10");
    }
    
}
