package patricia.suarezdiazt02;

import java.util.Scanner;

public class ej06 {

    public static void main(String[] args) {
        /*Un sistema de ecuaciones lineales de la forma:
        ax + by = c
        dx + ey = f
        puede resolverse utilizando las siguientes fórmulas:
        x= ce −bf
           ae−bd 
        y= af −cd
           ae−bd 
        Realizar un programa que lea por teclado los dos conjuntos de coeficientes (a, b y c, y d, e y f) y calcule los valores para ‘x’ e ‘y’ según la fórmula descrita ¿Existen
        algunos casos para los cuales este algoritmo no funcione? Nota: cuando en matemáticas se escriben dos variables juntas, por ejemplo ‘ce’ quiere decir ‘c por e’.*/
        Scanner t = new Scanner(System.in);
        float x,a,b,c,d,e,f,y;
        System.out.print("Dime el valor de a ");
        a = t.nextFloat();
        System.out.println("Dime el valor de b ");
        b = t.nextFloat();
        System.out.println("Dime el valor de c ");
        c = t.nextFloat();
        System.out.println("Dime el valor de d ");
        d = t.nextFloat();
        System.out.println("Dime el valor de e ");
        e = t.nextFloat();
        System.out.println("Dime el valor de f ");
        f = t.nextFloat();
        if (a*e-b*d!=0){
            x=(c*e-b*f)/(a*e-b*d);
            y=(a*f-c*d)/(a*e-b*d);
            System.out.println("El resultado de x es:" +x);
            System.out.println("El resultado de y es:" +y);
        }
        else{
            System.out.println("no se puede resolver");
        }
        
    }
}
