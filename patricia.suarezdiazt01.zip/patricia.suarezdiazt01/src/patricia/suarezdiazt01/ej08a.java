
package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej08a {

    public static void main(String[] args) {
       Scanner t = new Scanner (System.in);
       int edad1, edad2, edad3, edad4;
       float media;
        System.out.println("Cuantos años tienes?");
        edad1=t.nextInt();
        System.out.println("Cuantos años tienes?");
        edad2=t.nextInt();
        System.out.println("Cuantos años tienes?");
        edad3=t.nextInt();
        System.out.println("Cuantos años tienes?");
        edad4=t.nextInt();
        
        media = (float)(edad1+edad2+edad3+edad4)/4;
        System.out.println("La media de edad es: " + media+ " años");
        
    }
    
}
