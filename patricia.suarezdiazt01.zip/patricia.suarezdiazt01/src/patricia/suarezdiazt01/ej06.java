
package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej06 {

    public static void main(String[] args) {
    Scanner t = new Scanner (System.in);
    double coste,precio, costeF,costeI;
    final double IMPUESTO = 20.0;
    final double TIENDA = 10.0;
    
    System.out.println("Dime el coste inicial");
    coste = t.nextDouble();
    costeF= coste*TIENDA/100 +coste;
    costeI=costeF*IMPUESTO/100;
    precio=costeI+costeF;

    System.out.println("Precio final "+precio+"€");
    }
    
}
