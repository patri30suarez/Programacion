
package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej03 {

    public static void main(String[] args) {
        Scanner t = new Scanner (System.in);
        int num1,num2,suma,resta;
        float division;
        
        System.out.println("Dime el primer numero");
        num1=t.nextInt();
        System.out.println("Dime el segundo numero");
        num2=t.nextInt();
        
        suma=num1+num2;
        resta=num1-num2;
        division=num1/(float)num2;
        System.out.println("La suma es "+suma);
        System.out.println("La resta es "+resta);
        System.out.println("La division es "+division);

    }
    
}
