
package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej02 {

    public static void main(String[] args) {
        Scanner t = new Scanner (System.in);
        float euros,dolares;
        final float cambio=1.14f;
        
        System.out.println("Dime una cantidad en dolares");
        dolares=t.nextFloat();
        euros=dolares/cambio;
        System.out.println("Son "+euros+"");
    }
    
}
