package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej10 {

    public static void main(String[] args) {
    Scanner t = new Scanner (System.in);
      double hypo,cateto1,cateto2;
      System.out.println("Cuanto mide el primer cateto");
      cateto1=t.nextDouble();
      System.out.println("Cuantos años tiene?");
      cateto2=t.nextDouble();
      try { hypo=cateto1/cateto2;} catch( Exception e ) {hypo=0;}
     // hypo = Math.sqrt(Math.pow(cateto1, 2) + Math.pow(cateto2, 2));
      hypo=Math.hypot(cateto1, cateto2); //utilidad para calcular la hipotenusa
      System.out.println("La hipotenusa: " + hypo+ " cm");
    }
}
