
package patricia.suarezdiazt01;

import java.util.Scanner;


public class ej05 {

  
    public static void main(String[] args) {
       Scanner t = new Scanner (System.in); 
       float Celsius,Fahrenheit,pulgada,cm;
       
       System.out.println("Dime una temperatura en Celsius");
        Celsius=t.nextFloat();
        Fahrenheit= 9/(5*Celsius)+32;
        System.out.println("Son "+Fahrenheit+"F");
        
        System.out.println("Dime una medida en pulgada");
        pulgada=t.nextFloat();
        cm=pulgada/0.3937f;
        System.out.println("Son "+cm+"cm");
    }
    
}
