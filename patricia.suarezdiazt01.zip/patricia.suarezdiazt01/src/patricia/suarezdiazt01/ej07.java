
package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej07 {

    public static void main(String[] args) {
        Scanner t = new Scanner (System.in);
        float kmUlt,kmAct,lUlt,lAct,consumo;
        System.out.println("Dime los km de cuando repostó");
        kmUlt=t.nextFloat();
        System.out.println("Dime los km actuales");
        kmAct=t.nextFloat();
        System.out.println("Dime los litros de aceite de cuando reposto");
        lUlt=t.nextFloat();
        System.out.println("Dime los litros actuales");
        lAct=t.nextFloat();
        
        consumo=(lUlt-lAct)/(kmAct-kmUlt)*100;
        System.out.println("El consumo medio es: " +consumo);
        
    }
    
}
