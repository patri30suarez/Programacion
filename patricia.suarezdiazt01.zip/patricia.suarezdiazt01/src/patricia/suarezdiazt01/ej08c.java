package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej08c {

    public static void main(String[] args) {
       Scanner t = new Scanner (System.in);
       float media;
        
        System.out.println("Cuantos años tiene?");
        media=t.nextInt();
        System.out.println("Cuantos años tiene?");
        media=t.nextInt()+media;
        System.out.println("Cuantos años tiene?");
        media=t.nextInt()+media;
        System.out.println("Cuantos años tiene?");
        media=t.nextInt()+media;
        media = media/4;
        System.out.println("La media de edad es: " + media+ " años");
    }
    
}

