
package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej01 {

    public static void main(String[] args) {
        Scanner t = new Scanner (System.in);
        float euros,dolares;
        final float cambio=1.14f;
        
        System.out.println("Dime una cantidad en euros");
        euros=t.nextFloat();
        dolares=euros*cambio;
        System.out.println("Son "+dolares+"$");
    }
    
}
