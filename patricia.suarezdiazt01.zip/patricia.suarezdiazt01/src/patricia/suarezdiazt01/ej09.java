package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej09 {

    public static void main(String[] args) {
    Scanner teclado = new Scanner (System.in);
        int var1, var2;

        System.out.print("Introduce var1: ");
        var1 = teclado.nextInt();
        System.out.print("Introduce var2: ");
        var2 = teclado.nextInt();
        //var1 = var2;
        //var2 = var1;
        var1=var1+var2;
        var2=var1-var2;
        var1=var1-var2;
        System.out.println("Ahora var1 es igual a var2 ");
        System.out.println("Ahora var2 es igual a var1 ");
        System.out.println("Ahora var1 es  "+var1);
        System.out.println("Ahora var2 es  "+var2);
    }
}
