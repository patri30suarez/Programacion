
package patricia.suarezdiazt01;

import java.util.Scanner;

public class ej08b {

    public static void main(String[] args) {
       Scanner t = new Scanner (System.in);
       int edad;
       float media;
        
        System.out.println("Cuantos años tiene?");
        edad=t.nextInt();
        System.out.println("Cuantos años tiene?");
        edad=t.nextInt()+edad;
        System.out.println("Cuantos años tiene?");
        edad=t.nextInt()+edad;
        System.out.println("Cuantos años tiene?");
        edad=t.nextInt()+edad;
        media = (float)edad/4;
        System.out.println("La media de edad es: " + media+ " años");
    }
    
}
