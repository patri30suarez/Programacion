
package patricia.suarezdiazt01;

import java.util.Scanner;


public class ej04 {

 
    public static void main(String[] args) {
  
    Scanner t = new Scanner (System.in);
    
    byte susp,suf,bien,not,sob;
    int aprob,top, alum;
            
        System.out.println("Introduce el numero de suspensos: ");
            susp = t.nextByte();
            
        System.out.println("Introduce el numero de suficientes: ");
            suf = t.nextByte();
            
        System.out.println("Introduce el numero de bien: ");
            bien = t.nextByte();
            
        System.out.println("Introduce el numero de notables: ");
            not = t.nextByte();
        
        System.out.println("Introduce el numero de sobresalientes: ");
            sob = t.nextByte();
            
             alum= susp+suf+bien+not+sob;
        
            aprob = (suf + bien + not + sob * 100)/alum ;
            
            top = (not + sob * 100) / alum;
            
        System.out.println("El porcentaje de los alumnos aprobados es: " + aprob);
        System.out.println("El porcentaje de los notables y los sobresalientes es: " + top);
        System.out.println("Los suspensos son: " + susp);
        
       
    }
    
}
